"""Three-candidate read-only action, real CLI MathML, strict presentation sidecar.

Only a new engineering fixture is seeded. No decisions/approvals or course files
are written; every tested resolve/review action must retain the seeded bytes.
"""
import copy,hashlib,json,os,runpy,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent;ext=root/'project/_extensions';checker=ext/'ctm-checkers';native=checker/'native-authoring';descriptor=json.loads((checker/'checkers.json').read_text());wheel=checker/descriptor['wheel'];wrapper=ext/'math-exercise/question-variants.py';evidence=root/'evidence/final-delta';evidence.mkdir(exist_ok=True)
project=root/'final-delta-project';project.mkdir(exist_ok=True)
env=dict(os.environ,CTM_VARIANTS_NATIVE=str(native),CTM_CHECKERS_WHEEL=str(wheel),CTM_VARIANTS_QUARTO='/workspace/.cloud-setup/quarto-1.8.27/bin/quarto',XDG_CACHE_HOME='/workspace/.cloud-setup/cache',XDG_DATA_HOME='/workspace/.cloud-setup/data',XDG_CONFIG_HOME='/workspace/.cloud-setup/config');env.pop('PYTHONPATH',None);env.pop('CTM_CHECKERS_SOURCE',None)
os.environ.update({key:env[key] for key in ['CTM_VARIANTS_NATIVE','CTM_CHECKERS_WHEEL']});sys.path[:0]=[str(native),str(wheel),str(wrapper.parent)]
from ctm_variants import history
from ctm_variants.producer import produce
from ctm_variants.github_bot import teacher_displays
from ctm_variants.model import VariantError
from ctm_checkers.variants import decode_context
from sympy import Rational
source='#| label: delta\n#| variables: |\n#|   a = pick([1, 2, 3])\n#| field-labels: Answer\n#| note: a={@a@}\nFraction _[{@a/3@}]\n#| solution\nThe answer is ${@a/3@}$.'
(project/'lesson.qmd').write_text('```{math-exercise}\n'+source+'\n```\n');(project/'_quarto.yml').write_text('project: {type: default}\nformat: html\n')
(project/'ctm_checkers.py').write_text("raise RuntimeError('hostile project import')\n")
parsed=runpy.run_path(str(wrapper),run_name='delta_fixture')['parse_source'](source);options,question=parsed
payload=dict(version=1,action='resolve-more',projectRoot=str(project),file='lesson.qmd',sourceFile='lesson.qmd',label='delta',manifest='_variants/delta.yml',source=source,options=options,question=question,approval='required',renderMode='review')
manifest=project/'_variants/delta.yml';assert not manifest.exists(),'fixture already seeded; inspect rather than overwrite'
def invoke(request,name,ok=True):
 result=subprocess.run([sys.executable,'-I',str(wrapper),'--stdin'],input=json.dumps(request),cwd=project,capture_output=True,text=True,env=env,timeout=60)
 (evidence/(name+'.stdout.json')).write_text(result.stdout);(evidence/(name+'.stderr')).write_text(result.stderr)
 if ok:assert result.returncode==0,result.stderr;return json.loads(result.stdout)
 assert result.returncode!=0 and not result.stdout;return result.stderr
initial=invoke(payload,'initial-readonly');assert len(initial['records'])==3 and not manifest.exists()
chosen=next(row for row in initial['records'] if decode_context(row['context'])[2]['Answer']==Rational(1,3))
seed=copy.deepcopy(initial['manifest']);seed['proposals']=[row for row in seed['proposals'] if row['record']['id']==chosen['id']];assert len(seed['proposals'])==1
history.write(manifest,seed,base_hash=None) # explicit fixture setup, no approvals
before=manifest.read_bytes();source_before=(project/'lesson.qmd').read_bytes()
more=invoke(payload,'existing-readonly-more');assert len(more['records'])==3 and more['counters']['tested']==2
assert manifest.read_bytes()==before and (project/'lesson.qmd').read_bytes()==source_before
assert len(history.load(manifest,'delta')[0]['proposals'])==1
assert 'requires explicit review mode' in invoke(dict(payload,renderMode='publish'),'publish-refused',False);assert manifest.read_bytes()==before
command=[sys.executable,'-I',str(wrapper),'--project',str(project),'--file','lesson.qmd','--label','delta','review','--html',str(evidence/'cli-review.html')]
review=subprocess.run(command,cwd=project,capture_output=True,text=True,env=env,timeout=60);(evidence/'cli-review.stdout.json').write_text(review.stdout);(evidence/'cli-review.stderr').write_text(review.stderr);assert review.returncode==0,review.stderr
page=(evidence/'cli-review.html').read_text();assert '<math xmlns="http://www.w3.org/1998/Math/MathML">' in page and '<mfrac>' in page and 'Input: <code>1/3</code>' in page
assert manifest.read_bytes()==before
context=dict(headSha='a'*40,producerSha='b'*40,event='workflow_dispatch',expectedHead='a'*40,runId=20,repositoryId=1,pullRequest=7)
definition=dict(label='delta',file='lesson.qmd',source=source,options=options,question=question)
envelope,pages=produce(project,context,{'previewBase':'https://preview.test/previews/variants-7/review'},definitions=[definition],resolve=lambda request:more)
q=envelope['questions'][0];assert all(set(row)=={'id','hash','note','snapshot','data','tests'} for row in q['records']);assert teacher_displays(q)==q['teacherDisplays'];assert '<mfrac>' in pages['review/delta.html']
bad_values=[{'absent':{'Answer':chosen['teacherDisplay']['Answer']}},{chosen['id']:{'wrong':chosen['teacherDisplay']['Answer']}},{chosen['id']:{'Answer':{'mathml':'<math><script>bad()</script></math>','latex':'1/3'}}}]
for value in bad_values:
 bad=copy.deepcopy(q);bad['teacherDisplays']=value
 try:teacher_displays(bad)
 except VariantError:pass
 else:raise AssertionError('invalid teacher sidecar accepted')
bad=copy.deepcopy(more);bad['records'][0]['teacherDisplay']='malformed'
try:produce(project,context,{'previewBase':'https://preview.test/review'},definitions=[definition],resolve=lambda request:bad)
except VariantError:pass
else:raise AssertionError('malformed producer sidecar accepted')
assert manifest.read_bytes()==before
for name,module in list(sys.modules.items()):
 if name.startswith('ctm_variants') and getattr(module,'__file__',None):assert Path(module.__file__).resolve().is_relative_to(native),(name,module.__file__)
summary={'scope':'Only final three-candidate read-only resolve-more / real disconnected CLI MathML / strict presentation sidecar delta. Fixture setup seeded one undecided proposal; tested actions made no history or source writes. No base15/19/99 or browser/engine campaign repeated.','resolveMore':{'initialCandidates':3,'seededUndecided':1,'resolvedAfterMore':3,'newlyTested':2,'diskProposalsRemain':1,'publishModeRefused':True},'realCliReview':{'mathMLFraction':True,'canonicalInputFallback':'1/3','readOnly':True},'strictSidecar':{'neutralRecordKeys':6,'validProjectedMetadata':True,'invalidCandidateFieldActiveMathMLAndProducerShapeRefused':4},'manifestSha256':hashlib.sha256(before).hexdigest(),'sourceSha256':hashlib.sha256(source_before).hexdigest(),'browserWheelSha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'nativeProducerPath':sys.modules['ctm_variants.producer'].__file__}
(evidence/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('PASS readonly resolve-more3/seed1/new2, realCLI fractionMathML+canonical input, strictsidecar4refusals, source/historyunchanged')
