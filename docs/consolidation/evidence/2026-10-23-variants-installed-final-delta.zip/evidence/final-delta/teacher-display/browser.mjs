import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const python=process.env.QUARTO_PYTHON||'python';
const fixture=`
import copy,sys
sys.path.insert(0,'/workspace/ctm-checkers/authoring')
sys.path.insert(0,'/workspace/work/variants-install/project/_extensions/ctm-checkers/ctm_checkers-0.6.1.dev0-py3-none-any.whl')
sys.path.insert(0,'/workspace/math-exercise/_extensions/math-exercise')
from sympy import Rational,Matrix,sqrt,Symbol
from variant_resolver import teacher_display_projection
from ctm_variants import history
from ctm_variants.model import snapshot,candidate
from ctm_variants.placeholders import _input
from ctm_variants.review import document,teacher_display
values={'fraction':Rational(2,3),'matrix':Matrix([[1,Rational(2,3)],[sqrt(2),5]]),'unsafe':Symbol('<img src=x onerror=window.__teacherInjected=true>')}
displays=teacher_display_projection(values)
assert set(displays)=={'fraction','matrix'}
for raw in ['<math><mtext onclick="alert(1)">x</mtext></math>','<!DOCTYPE math [<!ENTITY x "boom">]><math>&x;</math>','<math xmlns="http://evil.test/"><mi>x</mi></math>']:
 assert teacher_display({'mathml':raw,'latex':'x'}) is None
inputs={'fraction':_input(values['fraction']),'matrix':'[[1, 2/3], [sqrt(2), 5]]','unsafe':str(values['unsafe'])}
row=candidate('fixture',snapshot(['fixture'],inputs,{}),note='Renderer fixture only',tests={})
before=copy.deepcopy(row)
page=document({'manifest':history.empty('fixture-q'),'baseHash':None,'records':[row]},teacher_displays={'fixture':displays})
assert row==before
print(page)
`;
const generated=spawnSync(python,['-c',fixture],{encoding:'utf8'});assert.equal(generated.status,0,generated.stderr);
writeFileSync('/workspace/work/teacher-display/fixture.html',generated.stdout);
const {chromium}=await import('/workspace/work/browser/playwright-system.mjs');const browser=await chromium.launch({headless:true});
try{
 const page=await browser.newPage();const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 await page.setContent(generated.stdout);
 assert.equal(await page.locator('.teacher-math math').count(),2);
 const geometry=await page.evaluate(()=>{
  const math=[...document.querySelectorAll('.teacher-math math')];
  const fraction=math[0].querySelector('mfrac'),numerator=fraction.children[0].getBoundingClientRect(),denominator=fraction.children[1].getBoundingClientRect();
  const rows=[...math[1].querySelectorAll('mtr')];const first=rows[0].children[0].getBoundingClientRect(),second=rows[0].children[1].getBoundingClientRect(),lower=rows[1].children[0].getBoundingClientRect();
  return{namespaces:math.map(node=>node.namespaceURI),fraction:{height:fraction.getBoundingClientRect().height,numeratorY:numerator.y,denominatorY:denominator.y},matrix:{rows:rows.length,cells:math[1].querySelectorAll('mtd').length,firstX:first.x,secondX:second.x,upperY:first.y,lowerY:lower.y,fences:[...math[1].querySelectorAll('mo')].map(node=>node.textContent)}};
 });
 assert.deepEqual(geometry.namespaces,['http://www.w3.org/1998/Math/MathML','http://www.w3.org/1998/Math/MathML']);
 assert.ok(geometry.fraction.height>0&&geometry.fraction.numeratorY<geometry.fraction.denominatorY);
 assert.equal(geometry.matrix.rows,2);assert.equal(geometry.matrix.cells,4);assert.ok(geometry.matrix.firstX<geometry.matrix.secondX&&geometry.matrix.upperY<geometry.matrix.lowerY);assert.ok(geometry.matrix.fences.includes('[')&&geometry.matrix.fences.includes(']'));
 assert.equal(await page.locator('img').count(),0);assert.equal(await page.evaluate(()=>window.__teacherInjected),undefined);
 assert.match(await page.locator('.teacher-input').last().textContent(),/<img src=x onerror=/);
 assert.equal(await page.locator('.teacher-input code').first().textContent(),'2/3');assert.deepEqual(errors,[]);
 const report={passed:7,browser:browser.version(),scope:'canonical late exact-value teacher projection plus shared overview native MathML rendering/sanitization; no grading or first-visit acceptance',pageErrors:errors,geometry};
 writeFileSync('/workspace/work/teacher-display/browser.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
}finally{await browser.close();}
