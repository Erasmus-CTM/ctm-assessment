import hashlib,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent
project=root/'project';ext=project/'_extensions'
record=json.loads((project/'.private-extensions/resolved-repos.json').read_text())
for name,row in record['repositories'].items():
 assert not row['dirty_files']
 print(name,row['commit'],'clean source snapshot')
for folder,files in record['extension_sha256'].items():
 for name,digest in files.items():
  assert hashlib.sha256((ext/folder/name).read_bytes()).hexdigest()==digest,(folder,name)
print('Every canonical installed file matches package record')
checkers=ext/'ctm-checkers';d=json.loads((checkers/'checkers.json').read_text())
wheel=checkers/d['wheel'];native=checkers/'native-authoring'
sys.path[:0]=[str(wheel),str(native)]
import ctm_checkers,ctm_variants.orchestration as orchestration
assert str(ctm_checkers.__file__).startswith(str(wheel))
assert Path(orchestration.__file__).resolve().is_relative_to(native)
print('Installed checker wheel import:',ctm_checkers.__file__)
print('Installed native orchestration import:',orchestration.__file__)
assert hashlib.sha256(wheel.read_bytes()).hexdigest()==d['sha256']
print('Browser wheel exact descriptor SHA256:',d['sha256'])
files=[name for name in record['extension_sha256']['ctm-checkers'] if name.startswith('native-authoring/')]
print('Recorded native files:',len(files))
