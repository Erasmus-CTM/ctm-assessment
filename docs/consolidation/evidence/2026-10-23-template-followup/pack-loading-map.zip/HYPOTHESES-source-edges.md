# First Check versus stage 2 — read-only source analysis

No new runtime observations, source changes, tests or reruns. This traces libs42 `626b546604f51c9cb738210c56d054d421581e02`, the common ordinary-check path in math31 `97a7dc5b` / math32 `74946e50`, and pyo11 `50795009`. The current math JS filesystem blob matches the exact74946 Git blob; its initial SymPy/bootstrap path is unchanged from97a7.

The old warm observation (Python/proxy2.94s, graded26.78s with background versus4.14s without, cells140.11s) establishes a22.64s differential in that run, not its cause. First Check finished long before cells: it did not await all stage2. The old cold21.14s terminal error was not successful grading. A render-failed diagnostic is no new runtime evidence. Current network-only diagnostic must run unchanged before considering more instrumentation.

## Confirmed source edges

| Edge | Exact source location | What follows |
|---|---|---|
| Interpreter publication versus background | runtime/pyodide-worker.js:562–570 and848–894 | init posts its RPC result and schedules startSetup separately. Shared buffers are configured before the proxy is published. No background-completion await in the published proxy promise. |
| Cells versus ordinary Check | pyo qpyodide-document-engine-initialization.js:59–96,107–118 | Cells explicitly await proxy.whenSetup. Math does not. Default background packages are pyodide_http, micropip and matplotlib plus patch_all. |
| Initial math preparation | math-exercise.js:1338–1392,152–173,904–941 | runCheck→prepareRuntime→ensureSympy→loadPackage(sympy)→ensureGuard→ensureCheckers, then exercise packages. The selected first fixture is the ordinary6×7=42 exercise, not a graphical/custom response. |
| Payload/bootstrap RPCs | pyodide-runtime.js:234–249,268–282,354–381 | Guard uses setGlobal then runPython. Checker install uses its bundled wheel, then CHECKERS_LOAD imports package modules. These are multiple ordinary worker RPC round trips; the checker payload is already a page script, not an additional wheel download from PyPI. |
| Actual grading RPCs | pyodide-runtime.js:424–460; math-exercise.js:1422–1460 | callCheckers serializes per-runtime work in checkerQueues; it sets the request, runs the Python checker, then cleanup. Multiple page exercises can share this queue. |
| Foreground priority bookkeeping | pyodide-worker.js:274–287,604–627 | busy counts queued/running RPCs; downloads counts missing-package loadPackage/loadPackagesFromImports commands only. runPython is busy but is not marked a network download. |
| Background network admission | pyodide-worker.js:205–212,424–435,445–488 | quiet pauses before a new HEAD/range/whole GET while foreground package commands are pending, then for2s after the last such command. It does not abort an already started fetch. Encoded/unknown representations use whole GET, so overlap can exceed one512KiB range. |
| Cached background path | pyodide-worker.js:321–342,453–456 | CacheStorage read→arrayBuffer→SHA verification occurs before quiet. A warm cached wheel can therefore be read/hashed/held while foreground work is pending, without any background network request. This is an overlap opportunity, not measured contention. |
| Install admission | pyodide-worker.js:223–237,520–535 | After prefetch, each package install joins the same commandQueue only when busy=0 and either300ms have passed since the last foreground command or its own5s admission wait has elapsed. Once queued/running, a later Check RPC waits for that one whole task. There is no preemption. |
| Lock fallback | pyodide-worker.js:526–532 | If readLock fails, prefetch is skipped and whenIdle installs can download under Pyodide's own package lock. This is a supported fallback, not evidence that it happened. |
| First error visibility | math-exercise.js:1451–1455; worker.js:591–598 | Worker RPC returns its original error message; math catches it and renders friendlyError, without logging the raw exception there. The original D2 clock records a terminal DOM result and at most120 characters of friendly status. A caught failure need not become pageerror/unhandledrejection. |

Source references above are line positions in `/workspace/work/libs-head-final42/_extensions/ctm-libs/runtime/`, `/workspace/math-exercise/_extensions/math-exercise/`, and `/workspace/pyodide-interaktiv/_extensions/pyodide-interaktiv/`.

The scheduler comment about a check meeting at most one install is not an unconditional latency bound: a long first preparation can have page/worker gaps exceeding300ms, and the5s ceiling is an admission wait rather than a maximum installation duration. No conclusion about actual number/duration of installs follows without timings. The60000ms slow-install status threshold is not a timeout.

## Hypotheses and discriminating observations

1. **Foreground package request delayed while a background transfer is already in flight.** Possible even with quiet: an admitted compressed whole GET is not cancelled. New request/finish timestamps can establish overlap and identify whether SymPy/mpmath finished near the delayed grade. Overlap alone cannot prove bandwidth causation. A warm run may have no background network at all.
2. **An already admitted install blocks a later foreground RPC.** Source permits it. It requires prefetch to have completed (or lock fallback) and install admission before the relevant RPC. Current network/stage-only diagnostics cannot see the exact queue interval; no claim that a22s delay was one install is justified.
3. **Cache validation or first-import/checker setup competes for worker time or resources.** Source permits cached reads/hashes before quiet and performs guard/payload/full-module initialization before the first actual grade. No request-heavy trace is required for this hypothesis. Both with/without cases initialize SymPy/checkers; those costs alone do not explain their difference without an observed interference or differing state.
4. **Other foreground consumers/retry/restart serialize ahead of this question.** Both worker commandQueue and checkerQueues exist. A worker close/replacement or repeated package requests would support investigating this path; lack of such evidence is not proof of no queue contention.
5. **Cold terminal failure is a package/initialization error rather than a timing miss.** The terminal DOM status is insufficient to identify it. Foreground loadPackage RPC does not add the explicit loaded-registry verification used for required init packages. This is a source difference only; do not change it unless the new actual failure identifies a missing/silent package result.

## Smallest next measurements, only if current raw diagnostic remains inconclusive

Keep the present network/console/pageerror/worker-life/stage clocks unchanged. Do not wrap RPCs, replace fetch, disable background work, alter comparator limits, or add a production priority fix in the current run.

If the next actual report still cannot distinguish the paths, propose a separately reviewed isolated diagnostic with bounded append-only events, preserving every existing error:

- Math: check-click; preparation begin/end/failure with original exception; actual checker-call begin/end/failure. Record question id and runtime generation, not answers or Python source.
- Worker: RPC id/type/package receive→dequeue→end, with busy/download counts; background prefetch/cache-validation begin/end; per-package install admitted/start/end/failure; lock-read success/fallback. Preserve exact native error text. Do not change queues or add artificial yields/delays.
- Use event ids and epoch timestamp plus native performance/timeOrigin for each context; do not subtract unaligned worker/page relative clocks. Retain capture byte/event limits and explicit truncation/drop markers. An incomplete trace remains inconclusive.

Those few boundary events distinguish an unqueued network overlap from queue waiting and from actual Python/payload execution. They are a proposal only; no diagnostic source or production change has been made here.

## D2 harness semantics that constrain interpretation

The original `loading-timing.cjs:131–179` polls25ms. It repeatedly clicks until the handler visibly takes effect, fills the actual stored answer, then accepts any terminal DOM result for the clock; only `.math-fb-ok` receives status `graded`. Error/incorrect/partial terminals remain failed D2 observations. `watchStages:184–190` polls actual mainPyodide and qpyodideCellsReady. `pageScenario:192–243` runs cold and warm pages inside one context; the warm page has a fresh interpreter but reuses that context's HTTP/CacheStorage state. With-background and without-background scenarios use separate contexts and are sequential, not simultaneously controlled network measurements. It waits for cells after the first terminal observation before opening the warm page. Therefore a warm cache may already contain stage2 wheels even when the earlier Check ended in error. No claim of Python-interpreter reuse is warranted.
