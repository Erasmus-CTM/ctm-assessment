# D2 on/off validity — exact626 /507 source

Read-only review; no changes to the running driver, production code or assertions.

The hook is still wired correctly:

- `loading-timing.cjs:192–199` creates a fresh context for each scenario; the off scenario uses context.addInitScript to set `globalThis.__ctmWorkerNoBackground = true` before navigation/scripts. The on scenario does not set it, and uses a separate context.
- Exact libs626 `pyodide-worker.js:848–864` reads that page-global flag while constructing the init RPC: strict true sends `background:{}`, otherwise the actual options.background object. No renamed hook, worker-scope lookup or stale conditional was found.
- Exact pyo507 `qpyodide-document-engine-initialization.js:107–118` normally supplies pyodide_http, micropip, matplotlib and the pyodide_http.patch_all Python step. Its only separate disable is `qpyodidePreloadPackages === false`. The producer defaults preload-packages true (`qpyodide.lua:558`; settings.js:18). The unchanged combined fixture YAML inspected here has no preload-packages:false override; actual rendered configuration remains the authority.
- Off suppresses only this configured stage2 object. It does not disable stage1 page packages, first Check's own SymPy/mpmath loads, checker installation or other page assets. Those requests in off mode are not evidence of a broken hook.
- Empty background makes setup() return with no package/run work and a successful setup message. On mode retains the real package/cache/prefetch/install path.

## Concrete observation/assertion gap

The source hook is valid, but the existing timing metric alone does not demonstrate that on mode **successfully completed** real stage2:

1. Pyo507 `qpyodideFollowWorker:73–96` awaits whenSetup, catches recoverable package failure, and then sets qpyodideCellsReady true in both success and recoverable failure paths. A worker-fatal failure is different and returns early.
2. `loading-timing.cjs:213–218` waits for the cells marker but catches and ignores its timeout. A null cells timestamp is not included in the final D2 failure predicate.
3. D2's final gate at365–367 checks terminal-grade errors, a non-null differential, and the unchanged2s limit. It does not assert an on-mode setup resolution, loaded package registry, real background configuration or absence of setup warnings.
4. Original grade clocks intentionally accept terminal UI results for timing, then classify only a correct result as graded. A cold terminal error is not successful first Check or successful background setup.

Therefore the old140.11s cells marker is a **settled/usable-cells marker**, not standalone proof of successful background package installation. A small new differential could coexist with failed background setup. This is an evidence-validity limit, not proof that the current run is invalid or the hook is ineffective.

## Read existing actual evidence before accepting a result

Use the current run's already captured network/console/stage data and rendered source first:

- Confirm the actual rendered preload flag is true and the loaded canonical worker hash is the expected626 implementation.
- For on mode, retain any `CTMWorker: stage2 could not...` / `qpyodide: the extra packages could not be loaded` messages. An observed such warning prevents claiming successful setup. Real background wheel requests establish work was attempted, not completed/installed. Warm cache may legitimately remove those network requests.
- For off mode, absence of the configured background downloads/patch work is expected; foreground SymPy and runtime requests remain allowed. Source wiring plus actual emitted configuration establishes the intended difference, but telemetry should not call all off-mode Python traffic stage2.
- If the current raw report lacks a successful setup outcome/registry observation, explicitly report that gap. Do not infer success solely from cellsReady or a small delta, silently alter this running test, rerun broadly, or weaken the2s/grade gate.

Only if more evidence is required afterward, a separately reviewed diagnostic could observe the existing `mainPyodide.whenSetup` promise resolution/rejection and loaded package state without replacing functions or changing scheduling. That is a future proposal, not an executed change or claim about the current run.

## Actual completed-run addendum

The unchanged diagnostic27cb/run40026037317/job120662683538 subsequently completed. Its exact JSON SHA256 is4d70bca6afed0271a452dfa2dd91fc24f188ad90359778463b0f7b16e1fbcc1c. Independently reading that raw JSON confirms six complete contexts, twelve graded outcomes and no dropped/truncated captures or setup-failure warnings. Each of three on contexts records one real matplotlib HEAD and one GET, both terminal; all three off contexts record none. The on paths have settled cells markers and the verified507 failure path would warn. This corroborates real successful on setup versus suppressed off setup for this run, without claiming a direct loadedPackages snapshot. Four median deltas0.15/0.34/0.08/0.09s meet the unchanged2s limit. Slow on grades at74.73s while cells settle141.51s. It does not identify the old delay cause or introduce a scheduler fix. See d2-hook-actual-validity.json for exact per-context observations.
