import importlib.util,shutil,tempfile
from pathlib import Path
path=Path('/workspace/math-exercise/_extensions/math-exercise/variants-review.py')
spec=importlib.util.spec_from_file_location('review_probe',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original=Path('/workspace/work/variants-install/project')
with tempfile.TemporaryDirectory(prefix='ctm-review-ui-probe-') as directory:
 root=Path(directory)
 for name in ('_extensions','_variants'):
  shutil.copytree(original/name,root/name)
 for name in ('lesson.qmd','_quarto.yml'):
  shutil.copyfile(original/name,root/name)
 review=module.Review(root,'lesson.qmd','q')
 try:
  with module.server(review) as server:
   print(server.review_url,flush=True)
   server.serve_forever()
 finally:review.preview_directory.cleanup()
