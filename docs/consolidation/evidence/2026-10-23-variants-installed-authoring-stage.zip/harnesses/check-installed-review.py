"""Read-only canonical installed local-review seam, no approval or files written."""
import hashlib,http.client,json,os,selectors,subprocess,sys
from pathlib import Path
from urllib.parse import urlsplit
root=Path(__file__).resolve().parent;project=root/'project';ext=project/'_extensions';checker=ext/'ctm-checkers'
descriptor=json.loads((checker/'checkers.json').read_text())
env=dict(os.environ,CTM_VARIANTS_NATIVE=str(checker/'native-authoring'),CTM_CHECKERS_WHEEL=str(checker/descriptor['wheel']),CTM_VARIANTS_QUARTO='/workspace/.cloud-setup/quarto-1.8.27/bin/quarto',XDG_CACHE_HOME='/workspace/.cloud-setup/cache',XDG_DATA_HOME='/workspace/.cloud-setup/data',XDG_CONFIG_HOME='/workspace/.cloud-setup/config')
env.pop('PYTHONPATH',None);env.pop('CTM_CHECKERS_SOURCE',None)
manifest=project/'_variants/q.yml';before=hashlib.sha256(manifest.read_bytes()).hexdigest()
p=subprocess.Popen([sys.executable,'-I',str(ext/'math-exercise/variants-review.py'),'--project',str(project),'--file','lesson.qmd','--label','q','--no-browser'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=env)
try:
 selector=selectors.DefaultSelector();selector.register(p.stdout,selectors.EVENT_READ);assert selector.select(8),'server did not start'
 line=p.stdout.readline().strip();assert line.startswith('Connected local variant review: '),line
 url=urlsplit(line.split(': ',1)[1]);connection=http.client.HTTPConnection(url.hostname,url.port,timeout=60)
 connection.request('GET',url.path);reply=connection.getresponse();body=reply.read();assert reply.status==200,body.decode()
 assert b'connected' in body and b'<html' in body.lower();assert reply.getheader('Cache-Control')=='no-store';connection.close()
 connection=http.client.HTTPConnection(url.hostname,url.port,timeout=10);connection.request('POST',url.path,body=b'{}',headers={'Origin':'http://unrelated.invalid','Content-Type':'application/json'});reply=connection.getresponse();assert reply.status==403;reply.read();connection.close()
 assert hashlib.sha256(manifest.read_bytes()).hexdigest()==before
 (root/'evidence/installed-review-readonly.json').write_text(json.dumps({'scope':'Actual canonical installed math helper routes through installed native package; read-only GET and unrelated-origin POST refusal only, no review decisions','pageBytes':len(body),'get':200,'unrelatedOriginPost':403,'manifestUnchanged':True},indent=2)+'\n')
 print('Installed local review GET200 + unrelated-originPOST403; manifest unchanged PASS')
finally:
 p.terminate()
 try:p.wait(timeout=5)
 except subprocess.TimeoutExpired:p.kill();p.wait()
 stderr=p.stderr.read();assert not stderr,stderr
