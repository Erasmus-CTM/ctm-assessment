"""Run only affected source-file extraction contracts through installed helper."""
import importlib.util,json,os,sys,unittest
from pathlib import Path
root=Path(__file__).resolve().parent
ext=root/'project/_extensions'
checker=ext/'ctm-checkers'
descriptor=json.loads((checker/'checkers.json').read_text())
os.environ['CTM_CHECKERS_WHEEL']=str(checker/descriptor['wheel'])
os.environ['CTM_VARIANTS_NATIVE']=str(checker/'native-authoring')
os.environ['CTM_VARIANTS_QUARTO']='/workspace/.cloud-setup/quarto-1.8.27/bin/quarto'
os.environ['XDG_CACHE_HOME']='/workspace/.cloud-setup/cache'
os.environ['XDG_DATA_HOME']='/workspace/.cloud-setup/data'
os.environ['XDG_CONFIG_HOME']='/workspace/.cloud-setup/config'
os.environ.pop('CTM_CHECKERS_SOURCE',None);os.environ.pop('PYTHONPATH',None)
spec=importlib.util.spec_from_file_location('installed_affected_tests',root/'sources/math-exercise/tests/test_variant_wrapper.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.WRAPPER=ext/'math-exercise/question-variants.py'
suite=unittest.TestSuite(m.WrapperTests(name) for name in ['test_downloaded_decision_resolves_current_file_and_rejects_changed_teacher','test_documentation_fence_does_not_define_an_authoritative_question','test_commented_and_raw_html_examples_are_not_authoritative_questions'])
result=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(not result.wasSuccessful())
