"""Targeted new helper/pool contracts against canonical installed source files."""
import json,os,sys,types,unittest
from pathlib import Path
root=Path(__file__).resolve().parent;ext=root/'project/_extensions';native=ext/'ctm-checkers/native-authoring';descriptor=json.loads((ext/'ctm-checkers/checkers.json').read_text());wheel=ext/'ctm-checkers'/descriptor['wheel']
os.environ.update(CTM_VARIANTS_NATIVE=str(native),CTM_CHECKERS_WHEEL=str(wheel),CTM_VARIANTS_QUARTO='/workspace/.cloud-setup/quarto-1.8.27/bin/quarto',XDG_CACHE_HOME='/workspace/.cloud-setup/cache',XDG_DATA_HOME='/workspace/.cloud-setup/data',XDG_CONFIG_HOME='/workspace/.cloud-setup/config');os.environ.pop('CTM_CHECKERS_SOURCE',None);os.environ.pop('PYTHONPATH',None)
sys.path[:0]=[str(native),str(wheel)]
name=sys.argv[1];source=root/'sources/math-exercise/tests'/('test_pool_authoring.py' if name=='pool' else 'test_variants_review_server.py');code=source.read_text()
if name=='pool':
 code=code.replace("ROOT/'_extensions/math-exercise/variant_resolver.py'",'Path('+repr(str(ext/'math-exercise/variant_resolver.py'))+')').replace("ROOT/'_extensions/math-exercise/question-variants.py'",'Path('+repr(str(ext/'math-exercise/question-variants.py'))+')')
else:code=code.replace('Path(__file__).resolve().parents[1] / "_extensions/math-exercise/variants-review.py"','Path('+repr(str(ext/'math-exercise/variants-review.py'))+')')
assert code!=source.read_text()
module=types.ModuleType('installed_affected_'+name);module.__file__=str(source);exec(compile(code,str(source),'exec'),module.__dict__)
case=module.PoolChecks if name=='pool' else module.PreviewTests if name=='preview' else module.ServerTests
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(case));sys.exit(not result.wasSuccessful())
