#!/usr/bin/env bash
# Reproduce the bounded installed one-page authoring-profile build; no deployment.
set -euo pipefail
source /workspace/.cloud-setup/activate.sh
example_source=${CTM_EXAMPLE_SOURCE:-/workspace/math-exercise}
example_fixture=$(mktemp -d /workspace/work/native-example-profile-reproduce-XXXXXX)
mkdir -p "$example_fixture/_extensions" "$example_fixture/_includes" "$example_fixture/_filters"
cp "$example_source/"{_quarto.yml,_quarto-variants-review.yml,generated-variants.qmd,example-site.css} "$example_fixture/"
cp -r "$example_source/_includes/variants" "$example_fixture/_includes/"
cp "$example_source/_filters/example-source.lua" "$example_fixture/_filters/"
cp -r "$example_source/_extensions/math-exercise" "$example_fixture/_extensions/"
cp -r /workspace/ctm-libs/_extensions/ctm-libs "$example_fixture/_extensions/"
cp -r /workspace/ctm-checkers/_extensions/ctm-checkers "$example_fixture/_extensions/"
cp -r /workspace/ctm-demo/_extensions/jsxgraph "$example_fixture/_extensions/"
cd "$example_fixture"
export CTM_COMPONENT_DEV=1 CTM_VARIANTS=review
export CTM_VARIANTS_NATIVE=/workspace/math-exercise/work/native-wrapper
export CTM_CHECKERS_WHEEL=/workspace/ctm-checkers/_extensions/ctm-checkers/ctm_checkers-0.6.1.dev0-py3-none-any.whl
quarto render generated-variants.qmd --profile variants-review
test -f _review-examples/generated-variants.html
test ! -e _variants
test ! -e _site/generated-variants.html
