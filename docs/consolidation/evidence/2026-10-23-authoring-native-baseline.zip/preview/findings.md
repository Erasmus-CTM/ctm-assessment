# Ordinary preview detection, Quarto 1.8.27

The controlled probe ran with both `quarto render page.qmd` and
`quarto preview page.qmd --no-browser --no-watch-inputs --no-serve`.
The network-enabled preview completed its render, started a local preview
listener and was stopped at the explicit ten-second command deadline (exit124).
Its filter report is exactly equal to the render report. No user environment
was enumerated; only the five named non-secret context variables in probe.lua
were inspected.

Both reports have nil public `quarto.doc.is_preview` and
`quarto.project.is_preview` APIs, empty profiles, unset `QUARTO_PREVIEW`, and
unset `QUARTO_PROJECT_RENDER_ALL`. Input, output, format and project identity
are identical. The first restricted preview attempt also rendered the probe
but failed when binding its listener; its report is retained separately.

Bundled source confirms `previewServer: true` in the internal render options
(`bin/quarto.js` around149369), but the public Lua doc/project table
(`share/pandoc/datadir/init.lua` around961–969) exposes no corresponding
preview field. `QUARTO_PROJECT_RENDER_ALL` is constructed for pre/post-render
hooks around125273, not as a preview flag. Guessing it would confuse a full
render with preview and weaken the publishing gate.

No reliable ordinary-preview detector was established. The canonical shared
helper accepts an explicit verified preview mode and preserves required
approval/default publish. An explicitly selected authoring/review profile or
canonical preview command can supply the mode without treating arbitrary
ordinary renders as preview. Automatic ordinary `quarto preview` handling
remains an acceptance gap against design15; this investigation does not clear
it or alter product source.
