return {{Pandoc=function(doc)
  local report={
    version=tostring(quarto.config.version()),
    input=quarto.doc.input_file,
    output=quarto.doc.output_file,
    project=quarto.project.directory,
    profile=quarto.project.profile,
    html=quarto.doc.is_format('html'),
    isPreviewAPI=type(quarto.doc.is_preview),
    isPreviewProjectAPI=type(quarto.project.is_preview),
    env={}
  }
  -- Explicitly selected non-secret context variables only; never enumerate env.
  for _,name in ipairs({'QUARTO_PROJECT_RENDER_ALL','QUARTO_PROJECT_DIR','QUARTO_PROJECT_OUTPUT_DIR','QUARTO_PROFILE','QUARTO_PREVIEW'}) do
    report.env[name]=os.getenv(name) or '<unset>'
  end
  local file=assert(io.open(assert(os.getenv('CTM_PROBE_OUTPUT')),'w'))
  file:write(quarto.json.encode(report))
  file:close()
  return doc
end}}
