"""Only the new trusted-producer pure contracts, using canonical installed modules."""
import hashlib,json,os,sys,types,unittest
from pathlib import Path
root=Path(__file__).resolve().parent
native=root/'project/_extensions/ctm-checkers/native-authoring'
source=root/'sources/ctm-checkers/tests/test_variants_producer.py'
code=source.read_text().replace("sys.path.insert(0,str(ROOT/'authoring'))",'sys.path.insert(0,'+repr(str(native))+')')
assert code!=source.read_text(),'producer test import seam changed; inspect before running'
sys.path.insert(0,str(native))
import ctm_variants.producer as producer
assert Path(producer.__file__).resolve().is_relative_to(native)
module=types.ModuleType('installed_producer_tests');module.__file__=str(source)
exec(compile(code,str(source),'exec'),module.__dict__)
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(module.ProducerTests))
(root/'evidence/installed-producer-harness.json').write_text(json.dumps({'scope':'New producer pure fixture contracts through canonical installed module; fake AST/resolver/API, no authored execution or generation campaign','sourceTestSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'producer':producer.__file__,'passed':result.wasSuccessful(),'count':result.testsRun,'vendorPatches':False},indent=2)+'\n')
sys.exit(not result.wasSuccessful())
