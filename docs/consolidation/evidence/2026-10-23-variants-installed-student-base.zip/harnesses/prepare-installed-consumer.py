"""Point the unchanged source test scenarios at canonical installed component bytes."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
source=root/'sources/math-exercise/tests/native-consumer.test.mjs'
s=source.read_text()
s=s.replace("'./helpers/", "'../tests/helpers/")
s=s.replace("new URL('../_extensions/math-exercise/'+name,import.meta.url)", "join(process.env.MATH_EXERCISE_EXTENSION,name)")
target=Path('/workspace/math-exercise/work/installed-native-consumer.test.mjs')
target.write_text(s)
(root/'evidence/installed-consumer-harness.json').write_text(json.dumps({'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'fixture':str(target),'changes':['helper import paths relative to scratch location','own(name) reads MATH_EXERCISE_EXTENSION instead of source extension'],'vendor_patches':False},indent=2)+'\n')
print(target)
