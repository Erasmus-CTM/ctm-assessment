"""Bounded actual Quarto build/codec gate, without browser/CDN acceptance."""
import json,os,subprocess,sys
from html.parser import HTMLParser
from pathlib import Path
root=Path(__file__).resolve().parent;project=root/'project';evidence=root/'evidence/consumer-build'
evidence.mkdir(exist_ok=True)
ext=project/'_extensions';checkers=ext/'ctm-checkers'
d=json.loads((checkers/'checkers.json').read_text());wheel=checkers/d['wheel']
env=dict(os.environ,PATH='/workspace/.cloud-setup/quarto-1.8.27/bin:'+os.environ['PATH'],XDG_CACHE_HOME='/workspace/.cloud-setup/cache',XDG_DATA_HOME='/workspace/.cloud-setup/data',XDG_CONFIG_HOME='/workspace/.cloud-setup/config',MATH_EXERCISE_PYTHON=sys.executable,CTM_VARIANTS_QUARTO='/workspace/.cloud-setup/quarto-1.8.27/bin/quarto',CTM_VARIANTS_NATIVE=str(checkers/'native-authoring'),CTM_CHECKERS_WHEEL=str(wheel),CTM_CHECKERS_EXTENSION=str(checkers),CTM_LIBS_EXTENSION=str(ext/'ctm-libs'))
env.pop('CTM_CHECKERS_SOURCE',None);env.pop('PYTHONPATH',None)
quarto='/workspace/.cloud-setup/quarto-1.8.27/bin/quarto'
class Payloads(HTMLParser):
 def __init__(self):super().__init__();self.items=[]
 def handle_starttag(self,tag,attrs):
  attrs=dict(attrs)
  if 'data-variants' in attrs:self.items.append((attrs,json.loads(attrs['data-variants'])))
source=(project/'question-source.txt').read_text()
(project/'zero.qmd').write_text('---\ntitle: Required and OPEN zero-approved gate\n---\n\n```{math-exercise}\n'+source.replace('#| label: q\n','#| label: q-zero\n')+'```\n')
(project/'bad.qmd').write_text('---\ntitle: Native source failure\n---\n\n```{math-exercise}\n'+source.replace('#| label: q\n','#| label: q-bad\n').replace('a = pick([1, 2])',"raise RuntimeError('expected authored execution failure')")+'```\n')
base=(project/'_quarto.yml').read_text();runs=[]
def render(name,mode,approval='required',ok=True):
 (project/'_quarto.yml').write_text(base.replace('approval: required','approval: '+approval))
 p=subprocess.run([quarto,'render',name],cwd=project,capture_output=True,text=True,env=dict(env,CTM_VARIANTS=mode),timeout=120)
 key=name.removesuffix('.qmd')+'-'+(mode or approval)
 (evidence/(key+'.stdout')).write_text(p.stdout);(evidence/(key+'.stderr')).write_text(p.stderr)
 runs.append(dict(file=name,approval=approval,mode=mode or 'publish',returncode=p.returncode))
 if ok:
  assert p.returncode==0,p.stderr
  html=(project/name.replace('.qmd','.html')).read_text();(evidence/(key+'.html')).write_text(html)
  parser=Payloads();parser.feed(html);assert len(parser.items)==1,parser.items
  attrs,data=parser.items[0];assert data.get('native') is True
  assert 'variables' not in data['options'] and 'tests' not in data['options'] and 'translations' not in data['options']
  assert data['variants']
  for row in data['variants']:
   assert row['context']['version']==1
   assert set(row['context'])=={'version','fields','variables','teacher','variant'}
   assert 'tests' not in row and 'teacherInputs' not in row and 'template' not in row
   assert '{@' not in row['question'] and '{#' not in row['question']
  return attrs,data,html,p.stderr
 assert p.returncode!=0,p.stdout
 return p.stderr
try:
 attrs,data,html,stderr=render('lesson.qmd','')
 assert len(data['variants'])==1
 row=data['variants'][0];assert row['n']==1 and row['context']['variant']=={'n':1,'id':row['id'],'hash':row['hash']}
 assert not row['proposal'] and data['approval']=='required'
 assert 'approved' in render('zero.qmd','',ok=False)
 assert not (project/'_variants/q-zero.yml').exists()
 for mode,approval in [('', 'optional'),('review','required')]:
  attrs,data,html,stderr=render('zero.qmd',mode,approval)
  assert len(data['variants'])==2 and data['unapproved'] is True
  assert all(r['n'] is None and r['proposal'] is True and r['context']['variant'] is None for r in data['variants'])
  assert 'math-variant-unapproved' in html
  assert 'unapproved' in stderr
  assert not (project/'_variants/q-zero.yml').exists()
 error=render('bad.qmd','','optional',ok=False)
 assert 'expected assignment or require(condition' in error,error
 assert not (project/'_variants/q-bad.yml').exists()
 (evidence/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
 print('Actual installed Quarto: approvedpositivecodec, requiredzero failure, OPEN/review testedproposalnullcodec/banners/warnings, sourcefailure hardstop PASS')
finally:(project/'_quarto.yml').write_text(base)
