# Focused installed component CLI evidence

One isolated synthetic sequence: Generate25 → explicitly approve one fixture
note → Generate25more. No real course notes were approved or course files
changed. The exact source tuple, native manifest fingerprint, commands, timings,
output sizes and all assertions are retained in `reports/summary.json` and
`verify.py`; raw stdout/stderr, normalized JSON and history checkpoints are in
`reports/`.

The source fixture has `a = pick(1, 80)`, a mandatory named teacher answer and one
real authored test asserting zero is wrong. All 50 resulting records passed both
the real teacher vector and that authored test. The approved history, proposal
prefix/order and n=1/id/hash survived the second batch.

The three negative controls are intentional failures: an HTML directory output,
5,000 actual prefix attempts in a rejected finite space, and an authored test
expecting an incorrect zero answer to be correct. They returned no successful
JSON and created no partial manifest; the 50-note history remained unchanged.
Those injected errors must not be counted as normal raw-clean successes.

Reproduce in a fresh scratch directory with the managed environment activated:

```sh
source /workspace/.cloud-setup/activate.sh
python -I verify.py
```

`verify.py` requires the recorded Git objects in the two `/workspace` repositories
and Quarto 1.8.27 at the recorded managed path. It refuses to overwrite a previous
project/evidence run. Both source commits remain available on GitHub; no old
local-computer path is a prerequisite. Native distribution is made with its
canonical `tools/build_authoring.py --install-extension` producer, then checked.

This evidence is a focused native/component check. It is not browser, live-course,
first-visit, static, merge or deployment acceptance. No live GitHub message,
decision commit or workflow dispatch was sent.
