#!/usr/bin/env python3
"""One focused isolated real CLI workflow, retaining exact source/evidence."""
import base64
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parent
MATH_REF = "9bf8a2f40cf459fa326abb604e894a42c8aa686e"
CHECKER_REF = "1a42281c3d7332df94e9b6e9df250ba7610369c7"
QUARTO = "/workspace/.cloud-setup/quarto-1.8.27/bin/quarto"
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)


def run(command, **kwargs):
    return subprocess.run(command, check=True, **kwargs)


def archive(repository, ref, destination):
    data = run(["git", "-C", str(repository), "archive", ref], capture_output=True).stdout
    destination.mkdir()
    with tarfile.open(fileobj=io.BytesIO(data)) as bundle:
        bundle.extractall(destination, filter="data")
    tree = run(["git", "-C", str(repository), "rev-parse", ref + "^{tree}"], capture_output=True, text=True).stdout.strip()
    return {"commit": ref, "tree": tree, "archiveSha256": hashlib.sha256(data).hexdigest()}


def save(name, value):
    (REPORTS / name).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


summary = {"version": 1, "passed": False, "syntheticOnly": True, "stages": [],
           "budgets": {"nativeRequestSeconds": 300, "phaseSeconds": 120,
                       "prefixAttempts": 5000, "sourceRecords": 1000, "retainedTapes": 1000,
                       "aggregateStdoutStderrBytes": 16 * 1024 * 1024}}
try:
    if (ROOT / "project").exists():
        raise RuntimeError("retain the earlier evidence; use a fresh scratch directory for another run")
    summary["math"] = archive(Path("/workspace/math-exercise"), MATH_REF, ROOT / "math-source")
    summary["checkers"] = archive(Path("/workspace/ctm-checkers"), CHECKER_REF, ROOT / "checker-source")
    project = ROOT / "project"
    extensions = project / "_extensions"
    extensions.mkdir(parents=True)
    shutil.copytree(ROOT / "math-source/_extensions/math-exercise", extensions / "math-exercise")
    shutil.copytree(ROOT / "checker-source/_extensions/ctm-checkers", extensions / "ctm-checkers")
    producer = [sys.executable, str(ROOT / "checker-source/tools/build_authoring.py"),
                "--install-extension", str(extensions / "ctm-checkers")]
    run(producer, capture_output=True, text=True)
    run([*producer, "--check"], capture_output=True, text=True)
    native_manifest = extensions / "ctm-checkers/native-authoring/native.json"
    summary["native"] = {"manifestSha256": hashlib.sha256(native_manifest.read_bytes()).hexdigest(),
                         "listedFiles": len(json.loads(native_manifest.read_text())["files"])}
    summary["versions"] = run([sys.executable, "-I", "-c",
        "import json,sys,sympy,yaml;print(json.dumps(dict(python=sys.version.split()[0],sympy=sympy.__version__,pyyaml=yaml.__version__)))"],
        capture_output=True, text=True).stdout.strip()
    hostile = project / "hostile cwd"
    hostile.mkdir()
    for name in ("json", "math", "ctm_variants", "ctm_checkers"):
        (hostile / (name + ".py")).write_text("raise RuntimeError('untrusted cwd import')\n")
    environment = dict(os.environ)
    environment.pop("CTM_VARIANTS_NATIVE", None)
    environment.pop("CTM_CHECKERS_WHEEL", None)
    environment["CTM_VARIANTS_QUARTO"] = QUARTO
    wrapper = extensions / "math-exercise/question-variants.py"
    source = """#| label: synthetic-80
#| variables: |
#|   a = pick(1, 80)
#| field-labels: Answer
#| note: synthetic a={#a#}
#| tests:
#|   - name: zero is wrong
#|     answers:
#|       Answer: '0'
#|     expect: wrong
Find $a={@a@}$ and enter its value: _[{#a#}].
"""
    (project / "lesson.qmd").write_text("```{math-exercise}\n" + source + "```\n")
    (ROOT / "verified-source.qmd").write_text((project / "lesson.qmd").read_text())

    def cli(stage, *arguments, file="lesson.qmd", label="synthetic-80", expected_error=None):
        command = [sys.executable, str(wrapper), "--project", str(project),
                   "--file", file, "--label", label, *map(str, arguments)]
        started = time.monotonic()
        completed = subprocess.run(command, cwd=hostile, env=environment, capture_output=True,
                                   text=True, timeout=315)
        elapsed = time.monotonic() - started
        (REPORTS / (stage + ".stdout")).write_text(completed.stdout)
        (REPORTS / (stage + ".stderr")).write_text(completed.stderr)
        receipt = {"stage": stage, "command": command, "exitCode": completed.returncode,
                   "elapsedSeconds": elapsed, "stdoutBytes": len(completed.stdout.encode()),
                   "stderrBytes": len(completed.stderr.encode()), "expectedError": expected_error}
        summary["stages"].append(receipt)
        save("summary.json", summary)
        print(json.dumps(receipt), flush=True)
        assert elapsed < 315
        assert receipt["stdoutBytes"] + receipt["stderrBytes"] < summary["budgets"]["aggregateStdoutStderrBytes"]
        if expected_error:
            assert completed.returncode != 0, stage
            assert completed.stdout == "", stage
            assert expected_error in completed.stderr, (stage, completed.stderr)
            return None
        assert completed.returncode == 0, (stage, completed.stderr)
        value = json.loads(completed.stdout)
        save(stage + ".json", value)
        return value

    def checked(records):
        for row in records:
            assert row["tests"]["passed"] is True
            assert row["tests"]["teacher"]["actual"]["status"] == "correct"
            tests = row["tests"]["tests"]
            assert len(tests) == 1 and tests[0]["name"] == "zero is wrong"
            assert tests[0]["actual"]["status"] == "wrong", tests

    first = cli("01-generate25", "generate25more", "--html", ROOT / "first-review.html")
    assert first["counters"]["tested"] == 25
    assert first["counters"]["source_records"] == 25
    assert first["counters"]["exhausted"] is False
    assert len(first["records"]) == 25
    assert all(row["context"]["variant"] is None and row["n"] is None for row in first["records"])
    checked(first["records"])
    manifest = project / "_variants/synthetic-80.yml"
    first_manifest = json.loads(manifest.read_text())
    assert len(first_manifest["proposals"]) == 25 and not first_manifest["decisions"]
    selected = first["records"][0]
    download = {"version": 1, "action": "decide-many", "projectRoot": str(project),
                "manifest": "_variants/synthetic-80.yml", "label": "synthetic-80",
                "baseHash": first["baseHash"], "records": first["records"],
                "decisions": [{"id": selected["id"], "hash": selected["hash"], "status": "approved",
                               "by": "synthetic-fixture", "date": "2026-10-23", "reason": "isolated fixture only"}]}
    request_file = ROOT / "synthetic-decision.json"
    request_file.write_text(json.dumps(download, ensure_ascii=False, indent=2) + "\n")
    approved = cli("02-approve-one", "apply", request_file)
    approved_manifest = json.loads(manifest.read_text())
    save("02-approved-manifest.json", approved_manifest)
    assert approved_manifest["proposals"] == first_manifest["proposals"]
    decision, = approved_manifest["decisions"]
    assert decision["n"] == 1 and decision["id"] == selected["id"] and decision["hash"] == selected["hash"]
    assert len(approved_manifest["events"]) == 1
    more = cli("03-generate25more", "generate25more", "--html", ROOT / "fifty-review.html")
    final = json.loads(manifest.read_text())
    save("03-final-manifest.json", final)
    assert more["counters"]["tested"] == 25
    assert more["counters"]["source_records"] == 50
    assert more["counters"]["duplicate_ids"] == 25
    assert more["counters"]["duplicate_notes"] == 0
    assert more["counters"]["replayed"] == 25 and more["counters"]["gone"] == 0
    assert more["counters"]["exhausted"] is False
    assert len(more["records"]) == 50
    assert len({row["id"] for row in more["records"]}) == 50
    assert len({row["note"] for row in more["records"]}) == 50
    assert len({row["hash"] for row in more["records"]}) == 50
    checked(more["records"])
    assert len(final["proposals"]) == 50
    assert final["proposals"][:25] == approved_manifest["proposals"]
    assert final["decisions"] == approved_manifest["decisions"]
    assert final["events"] == approved_manifest["events"]
    assert [row["id"] for row in more["records"][:25]] == [row["id"] for row in first["records"]]
    identities = [row["context"]["variant"] for row in more["records"] if row["context"]["variant"] is not None]
    assert identities == [{"n": 1, "id": selected["id"], "hash": selected["hash"]}]
    before_negative = manifest.read_bytes()
    bad_html = ROOT / "html-is-a-directory"
    bad_html.mkdir()
    cli("04-html-directory-fault", "generate25more", "--html", bad_html,
        expected_error="review HTML output must be a file")
    assert manifest.read_bytes() == before_negative
    budget_source = """#| label: budget-fixture
#| variables: |
#|   a = pick(1, 80)
#|   b = pick(1, 80)
#|   require(False)
#| field-labels: Answer
_[{#a#}]
"""
    (project / "budget.qmd").write_text("```{math-exercise}\n" + budget_source + "```\n")
    cli("05-explicit-attempt-budget-fault", "generate25more", file="budget.qmd", label="budget-fixture",
        expected_error="actual prefix attempt limit exceeded after 5000")
    assert not (project / "_variants/budget-fixture.yml").exists()
    assert manifest.read_bytes() == before_negative
    failed_source = source.replace("synthetic-80", "authored-fault").replace("expect: wrong", "expect: correct")
    (project / "authored-fault.qmd").write_text("```{math-exercise}\n" + failed_source + "```\n")
    cli("06-authored-test-fault", "generate25more", file="authored-fault.qmd", label="authored-fault",
        expected_error="authored tests")
    assert not (project / "_variants/authored-fault.yml").exists()
    assert manifest.read_bytes() == before_negative
    summary.update(passed=True, distinctTestedRecords=50, retainedApprovalNumber=1,
                   finalManifestSha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),
                   initialRecords=25, additionalRecords=25,
                   htmlReviewIsDisconnected=True, realCourseNotesApproved=False)
    save("summary.json", summary)
    print(json.dumps({"passed": True, "records": 50, "reports": str(REPORTS)}), flush=True)
except BaseException as error:
    summary["failure"] = type(error).__name__ + ": " + str(error)
    save("summary.json", summary)
    print(json.dumps({"passed": False, "failure": summary["failure"]}), flush=True)
    raise
