import json, hashlib, collections
from pathlib import Path
root=Path(__file__).parent
source=root/'chromium-provenance.json'
p=json.loads(source.read_text('utf-8')); es=p['cdp']['events']
requests={}; terminal=collections.defaultdict(list)
for e in es:
    q=e['params']; key=(e.get('targetId'),q.get('requestId'))
    if e['method']=='Network.requestWillBeSent': requests.setdefault(key,e)
    if e['method'] in ('Network.loadingFinished','Network.loadingFailed'):
        row={'method':e['method'],'at':e['at'],**q}
        if row not in terminal[key]:terminal[key].append(row)
def compact(e):
    q=e['params']; key=(e.get('targetId'),q['requestId']); i=q.get('initiator',{})
    return {'targetId':key[0],'requestId':key[1],'targetType':e.get('targetType'),'at':e['at'],'phase':e.get('phase'),'url':q['request']['url'],'range':q['request'].get('headers',{}).get('Range'),'frameId':q.get('frameId'),'loaderId':q.get('loaderId'),'initiatorType':i.get('type'),'initiatorURL':i.get('url','')[:200],'stack':[{k:f.get(k) for k in ('functionName','url','lineNumber','columnNumber')} for f in i.get('stack',{}).get('callFrames',[])[:2]],'terminals':terminal[key]}
urls={x['url'] for v in p['pendingBeforeTeardown'].values() for x in v}
nav=[]
for e in es:
    if e['method']=='Page.frameNavigated':
        f=e['params']['frame'];nav.append({'at':e['at'],'frameId':f['id'],'parentId':f.get('parentId'),'loaderId':f['loaderId'],'url':f['url'][:150]})
result={'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'functionalPassed':p['functionalPassed'],'functionalBaselinePassed':p['functionalBaselinePassed'],'rawPassed':p['rawPassed'],'cdpCommandsFailed':p['cdp']['commandsFailed'],'navigationLoaders':nav,'pendingRequestProvenance':[compact(e) for e in requests.values() if e['params']['request']['url'] in urls],'matplotlibRequests':[compact(e) for e in requests.values() if 'matplotlib-' in e['params']['request']['url']],'loadingFailed':[compact(requests[k]) for k,v in terminal.items() if any(t['method']=='Network.loadingFailed' for t in v) and k in requests]}
(root/'chromium-provenance-summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'rawPassed':p['rawPassed'],'functionalPassed':p['functionalPassed'],'baselinePassed':p['functionalBaselinePassed'],'loadingFailed':len(result['loadingFailed']),'matplotlibWorkerRequests':sum(x['targetType']=='worker' for x in result['matplotlibRequests']),'pending':{k:len(v) for k,v in p['pendingBeforeTeardown'].items()},'reportSha256':result['sourceSha256']}))
