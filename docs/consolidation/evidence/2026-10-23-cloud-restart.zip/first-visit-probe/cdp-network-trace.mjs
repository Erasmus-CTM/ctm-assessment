// Passive CDP provenance: no request interception, worker replacement, or debugger pause.
import net from 'node:net';
export async function unusedPort(){const server=net.createServer();await new Promise(done=>server.listen(0,'127.0.0.1',done));const port=server.address().port;await new Promise(done=>server.close(done));return port;}
export async function traceBrowser(port,report){
  const version=await (await fetch('http://127.0.0.1:'+port+'/json/version')).json();
  const socket=new WebSocket(version.webSocketDebuggerUrl);
  await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
  const pending=new Map(),targets=new Map();let next=0,pageReady=false;
  report.cdp={startedAt:Date.now(),endpointProtocol:version['Protocol-Version'],waitForDebuggerOnStart:false,events:[],commandsFailed:[]};
  function send(method,params={},sessionId){return new Promise((resolve,reject)=>{const id=++next;pending.set(id,{resolve,reject,method});socket.send(JSON.stringify({id,method,params,...(sessionId?{sessionId}:{})}));});}
  const filter=[{type:'page'},{type:'iframe'},{type:'worker'},{type:'service_worker'},{exclude:true}];
  const auto={autoAttach:true,waitForDebuggerOnStart:false,flatten:true,filter};
  const methods=new Set(['Network.requestWillBeSent','Network.requestWillBeSentExtraInfo','Network.responseReceived','Network.responseReceivedExtraInfo','Network.dataReceived','Network.loadingFinished','Network.loadingFailed','Network.requestServedFromCache','Page.frameNavigated','Page.frameDetached','Page.lifecycleEvent','Runtime.executionContextCreated','Runtime.executionContextDestroyed','Runtime.executionContextsCleared','Runtime.exceptionThrown','Target.targetCreated','Target.targetInfoChanged','Target.targetDestroyed','Target.attachedToTarget','Target.detachedFromTarget']);
  socket.addEventListener('message',async event=>{
    const message=JSON.parse(String(event.data));
    if(message.id){const command=pending.get(message.id);if(command){pending.delete(message.id);message.error?command.reject(new Error(command.method+': '+message.error.message)):command.resolve(message.result);}return;}
    const info=targets.get(message.sessionId);
    if(methods.has(message.method))report.cdp.events.push({at:Date.now(),phase:report.phase,sessionId:message.sessionId||null,targetId:info?.targetId,targetType:info?.type,targetURL:info?.url,method:message.method,params:message.params});
    if(message.method==='Target.attachedToTarget'){
      const {sessionId,targetInfo}=message.params;targets.set(sessionId,targetInfo);
      for(const [method,params] of [['Network.enable',{}],['Runtime.enable',{}],...(targetInfo.type==='page'||targetInfo.type==='iframe'?[['Page.enable',{}],['Page.setLifecycleEventsEnabled',{enabled:true}]]:[]),['Target.setAutoAttach',auto]]){
        try{await send(method,params,sessionId);if(method==='Network.enable'&&targetInfo.type==='page')pageReady=true;}catch(error){report.cdp.commandsFailed.push({at:Date.now(),sessionId,target:targetInfo,method,error:String(error)});}
      }
    }
  });
  await send('Target.setDiscoverTargets',{discover:true});await send('Target.setAutoAttach',auto);
  return {async waitForPage(){const end=Date.now()+10000;while(!pageReady&&Date.now()<end)await new Promise(done=>setTimeout(done,20));if(!pageReady)throw new Error('Passive CDP page Network domain not enabled');},close(){report.cdp.closedAt=Date.now();socket.close();}};
}
