import json,sys,collections
j=json.load(open(sys.argv[1])); trace=j['trace'];docs={}
for e in trace:
 if 'documentId' in e:
  d=docs.setdefault(e['documentId'],{'constructors':{},'targets':{},'deliveries':collections.Counter(),'errors':[],'events':[]})
  if e['kind']=='construct':d['constructors'][str(e['id'])]=e['stack']
  if e['kind']=='observe':d['targets'].setdefault(str(e['id']),[]).append(e['target'])
  if e['kind']=='delivery':d['deliveries'][str(e['id'])]+=1
  if e['kind']=='native-error':d['errors'].append(e)
  if e['kind'] in ['final','pagehide','store-event','trace-incomplete']:d['events'].append(e)
windows=[]
for i,e in enumerate(trace):
 if e['kind']=='native-error':windows.append(trace[max(0,i-20):i+5])
r={'browser':j['browser'],'checks':j['checks'],'rawErrors':j['errors'],'documents':docs,'errorWindows':windows,'actions':[e for e in trace if e['kind'].startswith('action-') or e['kind']=='context-closed'],'incomplete':any(e['kind']=='trace-incomplete' for e in trace),'caution':'Native observer events establish chronology; a callback adjacent to warning alone does not prove mutation ownership. Instrumentation cost differs from original natural run.'}
print(json.dumps(r,indent=2))
