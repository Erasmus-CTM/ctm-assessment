// Actual Quarto package pages in Chromium, Firefox and WebKit. No component
// scripts, editor adapters, store implementation or Python runtime are replaced.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import * as playwright from 'playwright';
import {serve} from '../../tools/compare-browser.mjs';
import {instrument,denyStoreWrites} from './instrument.mjs';
import {traceResize} from './resize-trace.mjs';

const root=path.resolve(process.env.CTM_STORE_ROOT || '.store-integration');
const engine=process.env.CTM_BROWSER || 'chromium';
assert.ok(['chromium','firefox','webkit'].includes(engine));
const roots={course:path.join(root,'before','_site')};
const server=await serve(roots,true);
const base='http://127.0.0.1:'+server.address().port+'/course/';
let browser;
const checks=[], errors=[], trace=[];
let active;
function cell(page,id){return page.locator('[data-ctm-component="math-exercise"][data-ctm-id="'+id+'"]');}
const quiz=page=>page.locator('[data-ctm-quiz="mixed"] .ctm-progress');
const pagePanel=page=>page.locator('.ctm-progress-page .ctm-progress');
async function context(extra) {
  const ctx=await browser.newContext({serviceWorkers:'block',viewport:{width:1280,height:900}});
  await ctx.exposeBinding('__ctmResizeTrace',(_,event)=>{trace.push(event);});
  await ctx.addInitScript(traceResize);
  await ctx.addInitScript(instrument);
  if(extra) await ctx.addInitScript(extra);
  ctx.on('page',page=>{
    page.setDefaultTimeout(90000);
    page.on('dialog',dialog=>dialog.accept());
    page.on('pageerror',error=>errors.push({page:page.url(),phase:checks.length,message:error.message,stack:error.stack}));
  });
  return ctx;
}
async function open(ctx,name='index.html'){
  const page=await ctx.newPage();active=page;
  await goto(page,name);return page;
}
async function goto(page,name='index.html'){
  await page.goto(base+name,{waitUntil:'domcontentloaded'});
  await ready(page,name);
}
async function ready(page,name='index.html'){
  await page.locator('.ctm-save-bar').waitFor({state:'visible'});
  await page.waitForFunction(()=>window.CTMStore && window.__storeEntries.some(e=>e.options.component==='math-exercise'));
  if(name==='index.html') await page.waitForFunction(()=>
    window.__storeEntries.some(e=>e.options.component==='py-exercise') &&
    window.qpyodideCellContainer?.cells.find(c=>c.options.label==='store-cell')?.primaryUnit?.editor && window.qpyodideCellsReady && window.qpyodideStartupPhaseDone && window.__storeAudit.wrapped.includes('python.runCell'));
  await noRestorePython(page,name==='index.html');
}
async function noRestorePython(page,mixed=false) {
  const audit=await page.evaluate(()=>({requests:__storeAudit.pythonRequests,cells:__storeAudit.cellRuns,during:__storeAudit.duringRestore,checks:__storeAudit.checkerCalls,wrapped:__storeAudit.wrapped,studentRuns:__storeAudit.studentRuns,restores:__storeAudit.restores.length}));
  assert.ok(audit.wrapped.includes('runtime.callCheckers'),'spy wraps the actual runtime boundary');
  if(mixed) {
    assert.ok(audit.wrapped.includes('python.globals.set'),'spy observes actual structured Python requests');
    assert.ok(audit.wrapped.includes('python.runCell'),'spy observes actual worker plugin execution');
  }
  assert.deepEqual(audit.requests,[],'restoration must not dispatch private Python requests');
  assert.deepEqual(audit.cells,[],'restoration must not dispatch worker cell runs');
  assert.deepEqual(audit.during,[],'restore may not start Python or checker installation/calls');
  assert.ok(audit.restores>0,'the actual component restore path was observed');
  assert.deepEqual(audit.studentRuns,[],'neither saved code nor starter code is executed on restoration');
  assert.equal(audit.checks,0,'the test never asks a checker to regrade restored work');
}
async function reveal(page,id){
  await page.evaluate(id=>CTMNav.reveal([...document.querySelectorAll('[data-ctm-component="math-exercise"]')].find(e=>e.dataset.ctmId===id)),id);
}
async function seed(page,id,status,score,index=0){
  await page.evaluate(({id,status,score,index})=>{
    const entry=__storeEntries.filter(e=>e.options.element?.getAttribute('data-ctm-id')===id)[index];
    if(!entry)throw Error('Missing real component registration '+id);
    entry.handle.result({status,score});
  },{id,status,score,index});
}
async function saved(page,id,predicate) {
  await page.waitForFunction(({id,source})=>{
    const record=JSON.parse(localStorage.getItem(CTMStore.key(id)) || 'null');
    return record && (new Function('record','return ('+source+')(record)'))(record);
  },{id,source:predicate.toString()});
}
async function pyCode(page,code){
  await page.evaluate(code=>{
    const model=monaco.editor.getModels().find(model=>model.getValue().includes('def stored_add'));
    if(!model)throw Error('Actual Python Monaco model not found');
    model.setValue(code);
  },code);
}
async function pyRead(page){
  return page.evaluate(()=>__storeEntries.find(e=>e.options.component==='py-exercise').options.read()?.code || '');
}
async function codeCell(page,code){
  return page.evaluate(code=>{
    const unit=qpyodideCellContainer.cells.find(c=>c.options.label==='store-cell').primaryUnit;
    if(code!==null)unit.editor.setValue(code);
    return unit.editor.getValue();
  },code);
}
async function observeRemote(page) {
  await page.evaluate(()=>{
    window.__remoteStoreEvents=[];
    if(window.__remoteStoreObserved)return;
    window.__remoteStoreObserved=true;
    document.addEventListener('ctm:store-clear',event=>__remoteStoreEvents.push({type:event.type,detail:event.detail}));
    window.addEventListener('storage',event=>{
      if(event.key?.startsWith('ctm|1|'))__remoteStoreEvents.push({type:'storage',key:event.key,removed:event.newValue===null});
    });
  });
}
async function remoteReset(page,id) {
  // The page clock is paused, so poll from Node rather than relying on its rAF.
  for(let attempt=0;attempt<100;attempt++){
    const delivered=await page.evaluate(()=>__remoteStoreEvents.some(event=>event.type==='ctm:store-clear'));
    if(delivered && await cell(page,id).locator('input.math-input').inputValue()==='')return;
    await new Promise(resolve=>setTimeout(resolve,20));
  }
  const state=await page.evaluate(id=>({
    events:window.__remoteStoreEvents,
    record:localStorage.getItem(CTMStore.key(id)),
    reads:__storeAudit.readCalls
  }),id);
  state.input=await cell(page,id).locator('input.math-input').inputValue();
  throw Error('Remote clear did not reset '+id+': '+JSON.stringify(state));
}
async function showSaved(offer) {
  // Follow the reader's actual path: open its tab, then its native disclosure.
  // innerText on a collapsed details descendant differs across browser engines.
  assert.equal(await offer.evaluate(element=>element.open),false,'saved answer starts collapsed');
  await offer.evaluate(element=>CTMNav.reveal(element.parentElement));
  assert.equal(await offer.evaluate(element=>element.open),false,'navigation does not reveal the old answer automatically');
  await offer.locator(':scope > summary').click();
  assert.equal(await offer.evaluate(element=>element.open),true,'the real saved-answer summary opens its disclosure');
  await offer.locator('pre').waitFor({state:'visible'});
  assert.equal(await offer.locator('input,textarea,[contenteditable="true"]').count(),0,'old answers stay read-only');
  return offer.locator('pre').innerText();
}
async function assertRecordMissing(page,id){
  assert.equal(await page.evaluate(id=>localStorage.getItem(CTMStore.key(id)),id),null);
}
try {
  browser=await playwright[engine].launch({headless:true});
  for(let repetition=1;repetition<=3;repetition++){
  const ctx=await context(denyStoreWrites);
  const page=await ctx.newPage();active=page;
  async function action(name,fn){trace.push({kind:'action-start',repetition,name,at:Date.now()});try{return await fn();}finally{trace.push({kind:'action-end',repetition,name,at:Date.now()});}}
  await action('open-original-page',()=>goto(page));
  await action('reveal-scalar',()=>reveal(page,'store-scalar'));
  await action('fill-memory-only',()=>cell(page,'store-scalar').locator('input.math-input').fill('memory only'));
  await action('seed-correct',()=>seed(page,'store-scalar','correct',1));
  await action('assert-fallback-status',async()=>assert.ok((await page.locator('.ctm-save-status').innerText()).length));
  await action('assert-no-device-keys',async()=>assert.equal(await page.evaluate(()=>Object.keys(localStorage).filter(k=>k.startsWith('ctm|1|')).length),0));
  await action('navigate-original-page',()=>goto(page));
  await action('assert-answer-empty',async()=>assert.equal(await cell(page,'store-scalar').locator('input.math-input').inputValue(),''));
  await action('assert-no-restored-python',()=>noRestorePython(page));
  checks.push('unavailable device storage falls back without persisting or executing restored code');
  await page.evaluate(()=>window.__ctmResizeFinal());
  await ctx.close();
  trace.push({kind:"context-closed",repetition,at:Date.now()});
  }
  assert.equal(trace.some(event=>event.kind==='trace-incomplete'),false,'diagnostic trace must be complete');
  assert.deepEqual(errors,[],'actual rendered pages have no uncaught errors');
} finally {
  fs.writeFileSync(process.env.CTM_RO_REPORT || 'resize-diagnostic.json',JSON.stringify({browser:engine,checks,errors,trace},null,2));
  if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));
}
