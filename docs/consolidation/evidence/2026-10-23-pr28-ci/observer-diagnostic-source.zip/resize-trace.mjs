// Diagnostic only: native callbacks, entries and delivery timing are preserved.
export function traceResize() {
  const documentId=crypto.randomUUID();
  let bytes=0, count=0, stopped=false;
  function emit(event) {
    const item={...event,documentId,at:Date.now(),now:performance.now(),url:location.href};
    const text=JSON.stringify(item);
    if(stopped)return;
    if(++count>10000 || bytes+text.length>4*1024*1024) {
      stopped=true;window.__ctmResizeTrace({kind:'trace-incomplete',documentId,at:Date.now(),count,bytes});return;
    }
    bytes+=text.length;return window.__ctmResizeTrace(item);
  }
  const targetName=e=>({tag:e?.tagName,id:e?.id,className:String(e?.className||'').slice(0,300)});
  window.addEventListener('error',e=>emit({kind:'native-error',message:e.message,filename:e.filename,line:e.lineno}));
  document.addEventListener('DOMContentLoaded',()=>emit({kind:'dom-ready'}),{once:true});
  window.addEventListener('load',()=>emit({kind:'load'}),{once:true});
  window.addEventListener('pagehide',()=>emit({kind:'pagehide'}),{once:true});
  window.__ctmResizeFinal=()=>emit({kind:'final',count,bytes});
  for(const type of ['ctm:store-message','ctm:result','ctm:store-restore'])
    document.addEventListener(type,()=>emit({kind:'store-event',type,status:document.querySelector('.ctm-save-status')?.textContent}),true);
  const Native=window.ResizeObserver;
  let next=0;
  window.ResizeObserver=class extends Native {
    constructor(callback) {
      const id=++next;
      emit({kind:'construct',id,stack:new Error().stack});
      super(function(entries,observer){
        emit({kind:'delivery',id,entries:entries.map(e=>({target:targetName(e.target),width:e.contentRect.width,height:e.contentRect.height}))});
        try{return callback.call(this,entries,observer);}
        finally{emit({kind:'delivery-end',id});}
      });
      this.__ctmDiagnosticId=id;
    }
    observe(target,options){emit({kind:'observe',id:this.__ctmDiagnosticId,target:targetName(target)});return super.observe(target,options);}
    unobserve(target){emit({kind:'unobserve',id:this.__ctmDiagnosticId,target:targetName(target)});return super.unobserve(target);}
    disconnect(){emit({kind:'disconnect',id:this.__ctmDiagnosticId});return super.disconnect();}
  };
}
