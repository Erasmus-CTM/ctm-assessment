// Focused injected-fault check; preserves all raw errors, uses actual grading.
// node negative-loading.mjs URL jsxgraph|speech OUTPUT.json
import fs from 'node:fs';
import assert from 'node:assert/strict';
const [url, fault, output] = process.argv.slice(2);
assert.ok(url && output && ['jsxgraph', 'speech'].includes(fault));
const pw = await import(process.env.CTM_PLAYWRIGHT_MODULE || './playwright-system.mjs');
const browser = await pw.chromium.launch({headless:true});
const context = await browser.newContext({serviceWorkers:'block', viewport:{width:1280,height:900}});
const report = {scope:'intentional dependency failure; real runtime grading; not raw-clean or first-visit acceptance',url,fault,passed:false,injected:[],errors:[],failedRequests:[]};
context.on('console', message => {if (message.type()==='error') report.errors.push({type:'console',text:message.text(),location:message.location()});});
context.on('weberror', event => report.errors.push({type:'web',text:String(event.error())}));
context.on('requestfailed', request => report.failedRequests.push({url:request.url(),failure:request.failure()}));
await context.route('**/*', async route => {
  const target=route.request().url();
  const blocked=fault==='jsxgraph' ? /(?:jsxgraphcore|jsxgraph)\.js(?:[?#]|$)/i.test(target) : /(?:sre_browser|speech-rule-engine|mathmaps\/)/i.test(target);
  if(blocked){report.injected.push(target);await route.abort('failed');}else await route.continue();
});
const page=await context.newPage();
async function reveal(locator){
  const tabs=await locator.evaluate(e=>{const out=[];for(let n=e;n;n=n.parentElement)if(n.classList.contains('tab-pane'))out.unshift(n.getAttribute('aria-labelledby'));return out;});
  for(const id of tabs){const tab=page.locator('[id="'+id+'"]');if(await tab.getAttribute('aria-selected')!=='true')await tab.click();}
  for(const detail of (await locator.locator('xpath=ancestor::details[not(@open)]').all()).reverse())await detail.locator(':scope > summary').click();
}
try {
  await page.goto(url,{waitUntil:'domcontentloaded',timeout:90000});
  const board=page.locator('#ui-board iframe');await board.waitFor({state:'attached'});await reveal(board);await board.scrollIntoViewIfNeeded();
  await page.waitForFunction(()=>!!globalThis.monaco?.editor && !!globalThis.mainPyodide,{},{timeout:180000});
  const cell=page.locator('.py-exercise-cell[data-ctm-id="step4-ui-autosave"]');await reveal(cell);
  const input=cell.locator('.monaco-editor textarea');await input.focus();await page.keyboard.press('ControlOrMeta+A');
  await page.keyboard.insertText('def double(x):\n    return 2 * x\n');
  const code=await cell.locator('.monaco-editor').evaluate(element=>monaco.editor.getEditors().find(editor=>editor.getDomNode()===element)?.getValue());
  assert.equal(code,'def double(x):\n    return 2 * x\n','actual keyboard edit landed in the intended model');
  await cell.locator('.py-exercise-check').click();
  await cell.locator('.py-exercise-all-passed').waitFor({timeout:180000});
  report.python={summary:await cell.locator('.py-exercise-summary').innerText(),workerProxy:await page.evaluate(()=>!!globalThis.mainPyodide?.isWorkerProxy)};
  assert.equal(await cell.locator('.py-test-pass').count(),2);
  const deadline=Date.now()+10000;while(!report.injected.length && Date.now()<deadline)await page.waitForTimeout(100);
  assert.ok(report.injected.length,'fault must intercept an actual dependency request');
  report.passed=true;
} catch(error) {report.failure=String(error.stack||error);process.exitCode=1;}
finally {report.finalURL=page.url();report.runtime=await page.evaluate(()=>({isolated:crossOriginIsolated,coi:globalThis.qpyodideCoiOutcome,input:globalThis.qpyodideInputState})).catch(()=>null);await context.close();await browser.close();fs.writeFileSync(output,JSON.stringify(report,null,2));}
