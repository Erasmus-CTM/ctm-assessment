import * as pw from '/workspace/stack-wasm-maxima/node_modules/playwright/index.mjs';
export const chromium={launch:options=>pw.chromium.launch({...options,executablePath:'/usr/bin/chromium',proxy:{server:process.env.HTTPS_PROXY,bypass:'<-loopback>,localhost,127.0.0.1'}})};
export const firefox=pw.firefox,webkit=pw.webkit;
