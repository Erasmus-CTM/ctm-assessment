import {createServer} from 'node:http';
import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {chromium} from 'playwright';
const root = new URL('../_extensions/math-exercise/', import.meta.url);
const html = `<!doctype html><div class="math-exercise-cell" id="e" data-label="task" data-ctm-id="task" data-ctm-source="0123456789abcdef" data-mode="equivalent" data-fields="[]" data-field-labels="[]" data-storage-variants="[]"><div class="math-exercise-question"><input class="math-input" id="e-f1" data-answer="42"></div><button class="math-check-btn">Check</button><button class="math-legend-btn">Help</button><div class="math-legend-panel"></div><div class="math-feedback-area"></div></div><script src="/matrix-input.js"></script><script src="/math-store.js"></script><script src="/math-exercise.js"></script>`;
const server = createServer((req,res)=>{
 if(req.url==='/'){res.setHeader('Content-Type','text/html');res.end(html);return;}
 if(['/matrix-input.js','/math-store.js','/math-exercise.js'].includes(req.url)){res.setHeader('Content-Type','text/javascript');res.end(readFileSync(new URL(req.url.slice(1),root)));return;}
 res.statusCode=404;res.end('Intentional missing renderer');
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
const page=await browser.newPage();
const errors=[],requests=[];
page.on('pageerror',e=>errors.push(e.message));page.on('requestfailed',r=>requests.push({url:r.url(),error:r.failure()}));
await page.addInitScript(()=>{
 window.__events=[];window.__changes=0;
 const math=new Proxy({legend:[],feedbackFieldSingle:'Answer',feedbackFieldNumbered:n=>'Field '+n,resPartial:n=>'Partial '+n,resScore:n=>'Score '+n,renderUnavailable:'Formatting unavailable'}, {get:(o,k)=>k in o?o[k]:String(k)});
 window.CTMLocales={table:()=>math};window.CTMAssets={url:()=>'/missing/'};
 window.CTMStore={register(options){window.__registration=options;return {restore:()=>({state:'empty'}),changed(){window.__changes++},result(value){window.__events.push(value)},clear(){options.clear()}}}};
 window.MathExerciseRuntime={trackInitialUI(p){window.__initialUI=p;p.catch(e=>window.__readinessError=e.message);return p},ensurePyodide:async()=>({loadPackage:async()=>{}}),ensureGuard:async()=>{},ensureCheckers:async()=>{},stopCount:()=>0,whenSlow:()=>()=>{},callCheckers:async()=>JSON.stringify({status:'correct',score:1})};
});
try{
 await page.goto('http://127.0.0.1:'+server.address().port);
 await page.locator('.math-render-unavailable').waitFor();
 await page.locator('input').fill('42');await page.locator('.math-check-btn').click();
 await page.waitForFunction(()=>window.__events.length===1);
 const result=await page.evaluate(()=>({error:window.__readinessError,status:window.__events[0].status,changes:window.__changes,inputs:window.__registration.read(),disabled:document.querySelector('.math-check-btn').disabled,notice:document.querySelector('.math-render-unavailable').textContent}));
 assert.ok(result.error);assert.equal(result.status,'correct');assert.equal(result.disabled,false);assert.ok(result.changes);assert.equal(result.inputs.fields.f1,'42');assert.equal(result.notice,'Formatting unavailable');
 writeFileSync(new URL('renderer-negative.json',import.meta.url),JSON.stringify({result,errors,requests,intentionalFault:true},null,2));console.log(JSON.stringify(result));
}finally{await browser.close();server.close();}
