const {chromium}=require('/workspace/ctm-assessment/node_modules/playwright');
const fs=require('node:fs'),http=require('node:http'),assert=require('node:assert/strict');
const root=process.cwd();
const html=`<!doctype html><main><div id="qpyodide-insertion-location-1"></div><div id="qpyodide-insertion-location-2"></div></main>
<script>
globalThis.qpyodideLang='en';globalThis.qpyodideCellsReady=false;
globalThis.qpyodideCellDetails=[{id:1,code:'print(42)',options:{context:'interactive'}}];
globalThis.QP_L=new Proxy({}, {get:(_,key)=>key});
globalThis.CTMLocales={table:()=>new Proxy({}, {get:(_,key)=>key})};
globalThis.CTMCopy={};globalThis.qpyodideInputAvailable=()=>false;
globalThis.tracked=[];globalThis.callbacks=[];globalThis.failures=[];
globalThis.MathExerciseRuntime={trackInitialUI(p){tracked.push(p);p.catch(e=>failures.push(e.message));}};
globalThis.require=(deps,ok,fail)=>callbacks.push({ok,fail});
globalThis.CTMLayout={fitEditor(){}};
globalThis.monaco={editor:{EndOfLineSequence:{LF:0},create(){return {getModel:()=>({setEOL(){}}),onDidFocusEditorText(){},onDidChangeModelContent(){},getValue:()=> 'print(42)'};}}};
</script>
<script type="module" src="/_extensions/pyodide-interaktiv/qpyodide-cell-classes.js"></script>
<script type="module" src="/_extensions/pyodide-interaktiv/qpyodide-cell-initialization.js"></script>`;
const server=http.createServer((req,res)=>{if(req.url==='/'){res.setHeader('content-type','text/html');return res.end(html);}const p=root+req.url;if(!p.startsWith(root+'/')||!fs.existsSync(p)){res.statusCode=404;return res.end();}res.setHeader('content-type','text/javascript');res.end(fs.readFileSync(p));});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});try{for(const fault of [false,true]){const page=await browser.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port);assert.deepEqual(errors,[]);assert.deepEqual(await page.evaluate(()=>({tracked:tracked.length,callbacks:callbacks.length,flag:qpyodideBuildingInitialUI,cells:qpyodideCellContainer.cells.length})),{tracked:1,callbacks:1,flag:false,cells:1});if(fault){await page.evaluate(()=>callbacks[0].fail(new Error('actual AMD failure')));assert.deepEqual(await page.evaluate(()=>failures),['actual AMD failure']);}else{await page.evaluate(async()=>{callbacks[0].ok();await tracked[0];qpyodideCellContainer.addCell(qpyodideCreateCell({id:2,code:'print(43)',options:{context:'interactive'}}));callbacks[1].ok();});assert.deepEqual(await page.evaluate(()=>({tracked:tracked.length,callbacks:callbacks.length,cells:qpyodideCellContainer.cells.length,flag:qpyodideBuildingInitialUI})),{tracked:1,callbacks:2,cells:2,flag:false});}assert.deepEqual(errors,[]);await page.close();}console.log('Chromium real separate ES modules: initial registration, AMD rejection, late editor exclusion PASS');}finally{await browser.close();server.close();}})().catch(e=>{console.error(e);server.close();process.exitCode=1;});
