# Bounded historical diagnostic audit

Actual remote assembly branch ref is1e2df4999d1e51da78ea8687fdfcbcba8a3ead88 (Git ref API and authenticated read-only Git fetch agree). Pull metadata still reports older base_sha65be5facbf67f900533a71cd950aa82e5c4c1e95; do not use that cached field as actual branch authority.

## Assessment43

Fresh GitHub mergeable=true, stateunstable; original false snapshot stale. Read-only `git merge-tree --write-tree --name-only` against actual assembly1e2 reports no conflicts. Result tree794946e6e574881c6cc04ebbe96ccbee7f80c13a has no file differences from assembly1e2. Its source changes are already present on the parent; no source conflict correction is needed. Existing WebKit diagnostic failure is a separate CI contract issue, not a merge conflict.

## Assessment41

Head9489b10c764f22c7aa4ae11867e6c6d74c596de9 conflicts with actual assembly1e2 in exactly four files. Tentative merge-treebe53dd21c24d5f50386e9fe32646a19e2d557635 only differs from assembly in conflict-marker hunks; NO other source differences remain.

- `.github/workflows/compare-assets-baseline.yml`: retain parent manualworkflow_dispatch/explicit broad-testing-campaign confirmation/campaign prerequisite, with tooling-reffallback. Old head reintroduces automatic PR broad jobs and removes prerequisite; reject that obsolete side.
- `tests/compare-rendered-assets.test.cjs`: retain parent checks for manual campaign gate/prerequisites/ref fallback and separately validated preload+UI-language composition tests. Old head has obsolete3jobs expectation and deletes new negative controls.
- `tools/compare-rendered/assets.mjs`: retain parent `markBoardChanges(A,items,context,page)` signature and scoped feedback-language composition validation. Canonical JSXGraph renderer proof uses A.doc; dropping A breaks modern renderer path. Keep all original strict mismatch checks.
- `tools/compare-rendered/expect/step4.yml`: retain parent's exact17de83e→e4ad81d renderer rule, backed by canonical byte reconstruction. Oldhead side merely lacks the newer rule.

Choosing parent in these exact conflicts gives assembly's exact tree; PR41 contains no unique remaining source feature. Treat as superseded historical evidence, not a newly green product contribution. Root should decide disposition/reconciliation under no-merge policy; no branch changes or merge commits made by this audit. The direct41/43 routes and diagnostic descendants are historical, not reasons to rerun protected courses or broad campaigns.

## Assessment51 minimal proposed correction

Historical run39934029987: all12native+12inactive startup samples clean. Native/original explicit editor interactions reproduce in both raw collectors4/4; editor integration/both clean4/4. Demanding natural startup reproduction is nondeterministic and does not measure product cleanliness.

Authorized isolated WIP `/workspace/work/assessment51-gate`: add pure diagnostic contract, preserve startup summary as observation, capture separate pageerror count at the existing measured editor boundary. For WebKit BOTH native and inactive-helper controls must each retain4samples and reproduce after that boundary in both raw collectors in the same sample. Both integration remains zero-errors in both collectors for every recorded sample, all engines. Existing nativeobserver/source hashes/parser/geometry/disposal/request/console assertions unchanged. Focused source-contract positive/negative checks and JSsyntax/diffcheck pass; independent review requested. No connectorpublication yet, actual new diagnostic CI still required.

Root authorized publication after source review; independent remote_audit CLEAR. Published51 exact4e4da0c4597ed27d63e84adf5e4185fd6e165f8b tree630ca33e9338e3888f8dd82f7b87f42db7ae8adf, singleparent4a8375f, author/tree/nonforce lease verified. Actual branch push diagnostic run40014440456 started automatically; render-local passed, threeengine actualcontrols underway. Sharededitor postboundarypageerror assertion additionally strengthened alongside oldwindowcollector check. Workflow runs purecontracttests before actualbrowser. Original failures retained, PRbody updated; no student course/loading acceptance inferred.

Final diagnostic result: render-local+Chromium+Firefox+WebKit ALL SUCCESS. Actual108 WebKit samples: native and inactive editor controls4/4 each have same-sample positive newerrors after editor boundary in BOTH collectors. Sharededitors4/4 zero newerrors; combinedpair zero rawerrors throughout. All60 startup samples remainclean(12eachmode) and are observations, not newly reproduced historicalfailure. Full4joblogs+artifactmetadata/digests+compactsamplefacts in assessment51-focused-evidence.zip,179495bytes,SHA256d73938bb5409f809c6a33461f6278185f3a8949264da210f67906dc51a8c52a1. No original126MBfixture duplication; artifactmetadata preserves exactfixture digest. Currenthead27checksPASS/1ordinarybuildrunning/0failed, freshmergeabletrue/drafttrue/unmerged. No coordinatedreadiness claim.

Final exacthead check state now ALL TERMINAL:28 success,1 deployskip,0 failure/cancel/pending. Ordinary five-tab/browser build completedPASS. FreshGitHub head4e4da0c/drafttrue/mergeabletrue/unmerged confirmed. PRbody updated with concrete result; root owns coordinatedroute/readiness disposition, no ready/merge/release claim made.
