# Final read-only PR inventory

Captured 2026-10-23 21:08:41 UTC. Saved scope: **59 PRs (originally57 drafts +2 non-drafts)**. Current: **28 drafts,31 non-drafts;59 open,0 merged**. The requested “57+3” does not match the saved snapshot; no60th entry was invented.

All designated current loading/authoring leaves and component prerequisites are now ready and their PR-triggered CI is green. **This does not mean all original PRs are green or ready.** Remaining draft groups:7 assessment foundation/asset prerequisites;9 historical diagnostics;2 superseded library alternatives;2 optional deliverables/transports;2 protected-course entries;4 checker reconciliation entries;1 native-runtime experiment;1 temporary artifact audit.

Current exact-head PR CI across all59:46 green/intentional-skip,8 red,4 cancelled/incomplete,1 running. Two merge conflicts remain: assessment41 and historical pyodide-interaktiv2. Foreign push cancellations (notably libs31's separate PR36 probe at the same SHA) are excluded; real PR cancellations are retained.

- Real current red: assessment28/35 prerequisite branches; assessment31/32/41/43/44 historical diagnostic/alternative branches; protected ingmat3a_ntnu17. Their errors are not waived by later compositions.
- Green draft prerequisites: assessment29/33/34/36/39. Source readiness and stale HOLD metadata need the owner's disposition; full offline/course acceptance is not inferred.
- Cancelled/incomplete: checker10–13 reconciled heads. Historical green ledgers do not clear these current PR runs.
- Running: stack-wasm-maxima13. Native reset/parity gates remain separately owned; audit16 explicitly says do not merge.
- Superseded: libs33/34 are preserved in reviewed union35; divergent duplicates should not be merged merely to empty the draft list. libs36 is the historical metadata probe; libs40 is a separately reviewed optional transport.
- Historical pyo2 remains non-draft/green but conflicting; the designated route is6→7→8→9→11.

No metadata/source changes, reruns, merges, retargets, deployments, tags or student-main writes were performed by this inventory.

| PR | Draft | Head | Actual base branch | PR CI | Role |
|---|---|---|---|---|---|
| [Erasmus-CTM/ctm-assessment#32](https://github.com/Erasmus-CTM/ctm-assessment/pull/32) | yes | c9af387a | consolidation/2026-10-step4-store | red | historical-diagnostic-or-alternative |
| [Erasmus-CTM/ctm-assessment#28](https://github.com/Erasmus-CTM/ctm-assessment/pull/28) | yes | 2d2f002c | main | red | active-prerequisite |
| [Erasmus-CTM/ctm-assessment#29](https://github.com/Erasmus-CTM/ctm-assessment/pull/29) | yes | 5e282436 | main | green-or-intentionally-skipped | active-prerequisite |
| [Erasmus-CTM/ctm-assessment#31](https://github.com/Erasmus-CTM/ctm-assessment/pull/31) | yes | 1605deeb | consolidation/2026-10-step4-store | red | historical-diagnostic-or-alternative |
| [Erasmus-CTM/ctm-assessment#33](https://github.com/Erasmus-CTM/ctm-assessment/pull/33) | yes | 294d5b86 | consolidation/2026-10-step5-assets | green-or-intentionally-skipped | active-prerequisite |
| [Erasmus-CTM/ctm-assessment#34](https://github.com/Erasmus-CTM/ctm-assessment/pull/34) | yes | 1e2df499 | consolidation/2026-10-step5-npm-lock | green-or-intentionally-skipped | active-prerequisite |
| [Erasmus-CTM/ctm-assessment#36](https://github.com/Erasmus-CTM/ctm-assessment/pull/36) | yes | 63980a23 | consolidation/2026-10-step5-npm-lock | green-or-intentionally-skipped | active-prerequisite |
| [Erasmus-CTM/ctm-assessment#40](https://github.com/Erasmus-CTM/ctm-assessment/pull/40) | yes | e96ff37c | consolidation/2026-10-offline-assembly | green-or-intentionally-skipped | optional-scoped-deliverable |
| [Erasmus-CTM/ctm-assessment#35](https://github.com/Erasmus-CTM/ctm-assessment/pull/35) | yes | 56b36b43 | consolidation/2026-10-step5-npm-lock | red | active-prerequisite |
| [Erasmus-CTM/ctm-assessment#39](https://github.com/Erasmus-CTM/ctm-assessment/pull/39) | yes | 94013514 | consolidation/2026-10-step5-compose-lock | green-or-intentionally-skipped | active-prerequisite |
| [Erasmus-CTM/ctm-assessment#41](https://github.com/Erasmus-CTM/ctm-assessment/pull/41) | yes | 9489b10c | consolidation/2026-10-offline-assembly | red / conflict | historical-diagnostic-or-alternative |
| [Erasmus-CTM/ctm-assessment#42](https://github.com/Erasmus-CTM/ctm-assessment/pull/42) | yes | bec2e2b8 | consolidation/2026-10-assets-comparison-followup | green-or-intentionally-skipped | historical-diagnostic-or-alternative |
| [Erasmus-CTM/ctm-assessment#43](https://github.com/Erasmus-CTM/ctm-assessment/pull/43) | yes | 31de8926 | consolidation/2026-10-offline-assembly | red | historical-diagnostic-or-alternative |
| [Erasmus-CTM/ctm-assessment#48](https://github.com/Erasmus-CTM/ctm-assessment/pull/48) | yes | 5ce8bd9b | consolidation/2026-10-offline-assembly | green-or-intentionally-skipped | historical-diagnostic-or-alternative |
| [Erasmus-CTM/ctm-assessment#50](https://github.com/Erasmus-CTM/ctm-assessment/pull/50) | yes | 49f0c63d | consolidation/2026-10-webkit-layout-trace | green-or-intentionally-skipped | historical-diagnostic-or-alternative |
| [Erasmus-CTM/ctm-assessment#52](https://github.com/Erasmus-CTM/ctm-assessment/pull/52) | no | 2c288f6b | consolidation/2026-10-offline-assembly | green-or-intentionally-skipped | active-integration |
| [Erasmus-CTM/ctm-assessment#44](https://github.com/Erasmus-CTM/ctm-assessment/pull/44) | yes | 7fa0b25b | consolidation/2026-10-webkit-runtime-setup | red | historical-diagnostic-or-alternative |
| [Erasmus-CTM/ctm-assessment#51](https://github.com/Erasmus-CTM/ctm-assessment/pull/51) | no | 4e4da0c4 | consolidation/2026-10-resize-upstream-controls | green-or-intentionally-skipped | active-integration |
| [Erasmus-CTM/ctm-assessment#56](https://github.com/Erasmus-CTM/ctm-assessment/pull/56) | no | 8b46f20e | consolidation/2026-10-jsxgraph-pin-1-2 | green-or-intentionally-skipped | active-integration |
| [Erasmus-CTM/py-exercise#10](https://github.com/Erasmus-CTM/py-exercise/pull/10) | no | 8289b3bb | main | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [aacchhee/ctm-demo#20](https://github.com/aacchhee/ctm-demo/pull/20) | no | 3f6336a4 | consolidation/2026-10-saving-quiz-candidate | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [aacchhee/ctm-demo#19](https://github.com/aacchhee/ctm-demo/pull/19) | no | 58fe28bb | main | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [aacchhee/quarto-course-template#1](https://github.com/aacchhee/quarto-course-template/pull/1) | no | 4e8c25b6 | main | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [Erasmus-CTM/py-exercise#13](https://github.com/Erasmus-CTM/py-exercise/pull/13) | no | 18e6f1eb | consolidation/2026-10-step5-assets | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [aacchhee/ingmat3a_ntnu#19](https://github.com/aacchhee/ingmat3a_ntnu/pull/19) | yes | d4f8693b | consolidation/2026-10-exercise-quizzes | green-or-intentionally-skipped | protected-course-diagnostic |
| [aacchhee/ingmat3a_ntnu#17](https://github.com/aacchhee/ingmat3a_ntnu/pull/17) | yes | 23e47057 | main | red | protected-course-release |
| [Erasmus-CTM/py-exercise#11](https://github.com/Erasmus-CTM/py-exercise/pull/11) | no | 2096710d | consolidation/2026-10-step4-store | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [Erasmus-CTM/math-exercise#31](https://github.com/Erasmus-CTM/math-exercise/pull/31) | no | 97a7dc5b | consolidation/2026-10-stable-variant-html | green-or-intentionally-skipped | active-prerequisite |
| [Erasmus-CTM/math-exercise#29](https://github.com/Erasmus-CTM/math-exercise/pull/29) | no | 98c8fe54 | consolidation/2026-10-step4-store | green-or-intentionally-skipped | active-prerequisite |
| [Erasmus-CTM/math-exercise#32](https://github.com/Erasmus-CTM/math-exercise/pull/32) | no | 74946e50 | consolidation/2026-10-first-visit-readiness | green-or-intentionally-skipped | active-integration |
| [Erasmus-CTM/math-exercise#27](https://github.com/Erasmus-CTM/math-exercise/pull/27) | no | 839afa3e | main | green-or-intentionally-skipped | active-prerequisite |
| [Erasmus-CTM/math-exercise#30](https://github.com/Erasmus-CTM/math-exercise/pull/30) | no | b282111d | consolidation/2026-10-step5-assets | green-or-intentionally-skipped | active-prerequisite |
| [Erasmus-CTM/stack-sympy#28](https://github.com/Erasmus-CTM/stack-sympy/pull/28) | no | e9b3f48b | main | green-or-intentionally-skipped | separately-owned-consumer |
| [Erasmus-CTM/pyodide-interaktiv#2](https://github.com/Erasmus-CTM/pyodide-interaktiv/pull/2) | no | 6cc7e6c1 | main | green-or-intentionally-skipped / conflict | historical-conflicting-alternative |
| [Erasmus-CTM/pyodide-interaktiv#6](https://github.com/Erasmus-CTM/pyodide-interaktiv/pull/6) | no | 8efc70b2 | feature/shared-feedback-integration | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [Erasmus-CTM/pyodide-interaktiv#7](https://github.com/Erasmus-CTM/pyodide-interaktiv/pull/7) | no | e85d9af4 | consolidation/2026-10-step4-store | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [Erasmus-CTM/pyodide-interaktiv#11](https://github.com/Erasmus-CTM/pyodide-interaktiv/pull/11) | no | 50795009 | feature/2026-10-preserve-runtime-order | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [Erasmus-CTM/pyodide-interaktiv#8](https://github.com/Erasmus-CTM/pyodide-interaktiv/pull/8) | no | 16561e66 | consolidation/2026-10-step5-assets | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [Erasmus-CTM/pyodide-interaktiv#9](https://github.com/Erasmus-CTM/pyodide-interaktiv/pull/9) | no | a5095406 | feature/2026-10-fast-python-ide | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [Erasmus-CTM/stack-wasm-maxima#13](https://github.com/Erasmus-CTM/stack-wasm-maxima/pull/13) | yes | 32140b0c | main | running | separately-owned-native-runtime |
| [Erasmus-CTM/ctm-checkers#10](https://github.com/Erasmus-CTM/ctm-checkers/pull/10) | yes | 951ef121 | main | cancelled-incomplete | separately-owned-checker-reconciliation |
| [Erasmus-CTM/stack-wasm-maxima#16](https://github.com/Erasmus-CTM/stack-wasm-maxima/pull/16) | yes | 357bce61 | main | green-or-intentionally-skipped | temporary-audit-only |
| [Erasmus-CTM/ctm-checkers#11](https://github.com/Erasmus-CTM/ctm-checkers/pull/11) | yes | 0e63965b | consolidation/2026-10-step2-s07 | cancelled-incomplete | separately-owned-checker-reconciliation |
| [Erasmus-CTM/ctm-checkers#12](https://github.com/Erasmus-CTM/ctm-checkers/pull/12) | yes | 74fa8e8e | consolidation/2026-10-step2-s05 | cancelled-incomplete | separately-owned-checker-reconciliation |
| [Erasmus-CTM/ctm-checkers#13](https://github.com/Erasmus-CTM/ctm-checkers/pull/13) | yes | 1ddf3db1 | consolidation/2026-10-step2-s10 | cancelled-incomplete | separately-owned-checker-reconciliation |
| [Erasmus-CTM/ctm-checkers#25](https://github.com/Erasmus-CTM/ctm-checkers/pull/25) | no | 5976f1a9 | main | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [Erasmus-CTM/ctm-checkers#23](https://github.com/Erasmus-CTM/ctm-checkers/pull/23) | no | b615e8b7 | main | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [Erasmus-CTM/ctm-checkers#21](https://github.com/Erasmus-CTM/ctm-checkers/pull/21) | no | 0f58fade | main | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [Erasmus-CTM/ctm-libs#33](https://github.com/Erasmus-CTM/ctm-libs/pull/33) | yes | 2ed1a338 | main | green-or-intentionally-skipped | source-superseded-alternative |
| [Erasmus-CTM/ctm-libs#34](https://github.com/Erasmus-CTM/ctm-libs/pull/34) | yes | c44cd395 | consolidation/2026-10-step5-assets | green-or-intentionally-skipped | source-superseded-alternative |
| [Erasmus-CTM/ctm-libs#31](https://github.com/Erasmus-CTM/ctm-libs/pull/31) | no | 9b15fdb2 | main | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [Erasmus-CTM/ctm-libs#35](https://github.com/Erasmus-CTM/ctm-libs/pull/35) | no | 41b2be0a | main | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [Erasmus-CTM/ctm-libs#37](https://github.com/Erasmus-CTM/ctm-libs/pull/37) | no | 62235ae3 | consolidation/2026-10-step5-assets-union | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [Erasmus-CTM/ctm-libs#36](https://github.com/Erasmus-CTM/ctm-libs/pull/36) | yes | 23507b34 | consolidation/2026-10-step4-store | green-or-intentionally-skipped | historical-diagnostic-or-alternative |
| [Erasmus-CTM/ctm-libs#39](https://github.com/Erasmus-CTM/ctm-libs/pull/39) | no | a6161c3e | consolidation/2026-10-layout-lifecycle | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [Erasmus-CTM/ctm-libs#38](https://github.com/Erasmus-CTM/ctm-libs/pull/38) | no | 98a626d2 | consolidation/2026-10-step5-assets-union | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [Erasmus-CTM/ctm-libs#42](https://github.com/Erasmus-CTM/ctm-libs/pull/42) | no | 626b5466 | consolidation/2026-10-layout-integration | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [Erasmus-CTM/ctm-libs#43](https://github.com/Erasmus-CTM/ctm-libs/pull/43) | no | d989919c | consolidation/2026-10-first-visit-readiness | green-or-intentionally-skipped | active-prerequisite-or-integration |
| [Erasmus-CTM/ctm-libs#40](https://github.com/Erasmus-CTM/ctm-libs/pull/40) | yes | 2cdd3b47 | consolidation/2026-10-mathjax-opaque-adaptor | green-or-intentionally-skipped | optional-source-alternative |
