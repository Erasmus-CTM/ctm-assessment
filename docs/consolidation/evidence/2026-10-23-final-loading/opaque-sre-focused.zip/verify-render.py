import base64,hashlib,json,subprocess,tempfile
from pathlib import Path
from html.parser import HTMLParser
r=Path('/workspace/work/sre-coi-proof/render');source=Path('/workspace/work/libs-sre/_extensions/ctm-libs/runtime/mathjax-opaque-adaptor.js').read_bytes();prefix=b'globalThis.CTM_COI_FRAME_STARTUP={protocol:"ctm-coi-frame-startup",version:1};\n'
class Parser(HTMLParser):
 def __init__(self):super().__init__();self.scripts=[];self.frames=[];self.head=False
 def handle_starttag(self,t,a):
  d=dict(a)
  if t=='head':self.head=True
  if t=='script':self.scripts.append((d,self.head))
  if t=='iframe':self.frames.append(d)
 def handle_endtag(self,t):
  if t=='head':self.head=False
report=[]
for name in ['default','blank','custom','false']:
 p=Parser();p.feed((r/(name+'.html')).read_text());coordinator=[(a,h) for a,h in p.scripts if 'ctm-coi-frame-startup' in a.get('src','')]
 if name=='default':
  assert len(coordinator)==1 and coordinator[0][1];assert not any(k in coordinator[0][0] for k in ['async','defer','type']);assert len(p.frames)==1
  body=base64.b64decode(p.frames[0]['src'].split(',',1)[1]);(r/'actual-default-child.html').write_bytes(body);child=Parser();child.feed(body.decode());scripts=[a for a,h in child.scripts];assert base64.b64decode(scripts[0]['src'].split(',',1)[1])==prefix+source;assert scripts[1]['id']=='MathJax-script' and 'async' in scripts[1];assert scripts[1]['src']=='https://cdn.jsdelivr.net/npm/mathjax@4.1.3/tex-mml-svg.js'
  with tempfile.NamedTemporaryFile(suffix='.js') as check:
   check.write(prefix+source);check.flush();subprocess.run(['node','--check',check.name],check=True)
 else:assert not coordinator
 report.append({'name':name,'coordinator_head_scripts':len(coordinator),'iframe_count':len(p.frames),'htmlSHA256':hashlib.sha256((r/(name+'.html')).read_bytes()).hexdigest()})
print(json.dumps({'passed':True,'cases':report,'scope':'Actual modified Meta + unchanged pinned JSXGraph e4ad renderer; exact flagged helper and original async MathJax script; false is metadata-only because upstream rejects boolean source paths'},indent=2))
