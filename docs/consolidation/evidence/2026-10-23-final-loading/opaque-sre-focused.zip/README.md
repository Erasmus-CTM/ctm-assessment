# SRE COI focused evidence

Production sources: library b90a341b05d7fef1d8078aa2642d5a72dbbd853e (4 paths), assessment 7a4208cefff1fbaeac788169bec325e30323bd85 (2 paths). Independent source review by math and remote_audit. 11 module tests; actual Quarto four producer contracts; real MathJax4.1.3/SRE retained/retired Chromium tests.

Browser boundary: exact npm vendor bytes served by local HTTP, opaque sandbox iframe (not original data URL), controlled parent settlement, genuine parent COOP/COEP + SAB/isolation. No Worker/runtime/vendor stubs, TLS bypass, timer fallback or error filtering. Not actual service-worker reload/CDN/Python acceptance. Original parent19 cancelled nemeth evidence remains separate.

Raw failed attempts retained: browser.log locale-response waiter registered too late; browser-final.log isolated parent required child response COEP; browser-final2.log first passing two-case run; browser-final3.log final passing run adds request epochs/asset inventory. npm-vendor.log cache setup failure corrected in npm-vendor-final.log. render.log/render-final.log retain early actual-render setup errors; render-verified.log final success. false is metadata-only because upstream JSXGraph rejects boolean preloader source path; no changed behavior claimed.

Browser receipt verifies load and canonical initialUI before controlled retention, zero worker/maps while pending, worker first request after decision; retired case no SRE requests. Exact executed source and vendor hashes recorded in browser.json. npm lockfile pins real assets. Render verifier additionally syntax-checks exact decoded flagged helper.
