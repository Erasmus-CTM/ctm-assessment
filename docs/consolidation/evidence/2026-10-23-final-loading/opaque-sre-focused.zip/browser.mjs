import http from 'node:http';
import {readFile,writeFile,stat} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const {chromium}=await import('/workspace/math-exercise/node_modules/playwright/index.mjs');
const root='/workspace/work/sre-coi-proof',library='/workspace/work/libs-sre/_extensions/ctm-libs/runtime';
const vendor=join(root,'vendor/node_modules/mathjax'),font=join(root,'vendor/node_modules/@mathjax/mathjax-newcm-font');
const source={};for(const name of ['coi-frame-startup.js','mathjax-opaque-adaptor.js','pyodide-runtime.js'])source[name]=await readFile(join(library,name));
const headers={'access-control-allow-origin':'*','cross-origin-resource-policy':'cross-origin','cache-control':'no-store'};
const requests=[],requestTimeline=[],assets={};let origin;
const control=`window.events=[];window.permissionRequests=[];window.qpyodideCoiSettled=new Promise(resolve=>window.releaseCoi=()=>{events.push({name:'decision',at:performance.now(),epoch:Date.now()});resolve();});document.addEventListener('DOMContentLoaded',()=>events.push({name:'parent-dcl',at:performance.now()}));window.addEventListener('load',()=>events.push({name:'parent-load',at:performance.now()}));window.addEventListener('message',e=>{if(e.data?.protocol==='ctm-coi-frame-startup')permissionRequests.push(e.data);if(e.data?.testEvent)events.push({name:e.data.testEvent,at:performance.now()});});`;
const server=http.createServer(async(req,res)=>{try{
 const path=new URL(req.url,'http://x').pathname;requests.push(path);requestTimeline.push({path,at:Date.now()});
 if(path==='/parent'){res.writeHead(200,{...headers,'cross-origin-opener-policy':'same-origin','cross-origin-embedder-policy':'require-corp','content-type':'text/html'});res.end(`<!doctype html><link rel="icon" href="data:,"><script>${control}</script><script src="/pyodide-runtime.js"></script><script src="/coi-frame-startup.js"></script><iframe id="frame" sandbox="allow-scripts" src="/child"></iframe>`);return;}
 if(path==='/child'){res.writeHead(200,{...headers,'cross-origin-embedder-policy':'require-corp','content-type':'text/html'});res.end(`<!doctype html><meta charset="utf-8"><script>window.CTM_COI_FRAME_STARTUP={protocol:'ctm-coi-frame-startup',version:1};window.MathJax={loader:{paths:{'mathjax-newcm':'${origin}/font'}},options:{enableSpeech:true,enableBraille:true}};window.addEventListener('load',()=>parent.postMessage({testEvent:'child-load'},'*'));</script><script src="/mathjax-opaque-adaptor.js"></script><script id="MathJax-script" async src="${origin}/mathjax/tex-mml-svg.js"></script><p>\\(x+1\\)</p>`);return;}
 if(source[path.slice(1)]){res.writeHead(200,{...headers,'content-type':'text/javascript'});res.end(source[path.slice(1)]);return;}
 let file=path.startsWith('/mathjax/')?resolve(vendor,path.slice(9)):path.startsWith('/font/')?resolve(font,path.slice(6)):null;
 if(!file||!(file.startsWith(vendor+'/')||file.startsWith(font+'/'))){res.writeHead(404,headers).end();return;}
 const bytes=await readFile(file);assets[file]={bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')};res.writeHead(200,{...headers,'content-type':file.endsWith('.js')?'text/javascript':file.endsWith('.json')?'application/json':'application/octet-stream'});res.end(bytes);
 }catch(error){res.writeHead(404,headers).end(error.message);}});
await new Promise(done=>server.listen(0,'127.0.0.1',done));origin='http://127.0.0.1:'+server.address().port;
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true});
const report={passed:false,scope:'Actual MathJax4.1.3/SRE and canonical coordinator/adaptor/runtime; controlled COI decision, HTTP opaque sandbox frame/local exact vendor transport; not actual service-worker reload/CDN/dataURL or Python acceptance',sources:Object.fromEntries(Object.entries(source).map(([name,bytes])=>[name,createHash('sha256').update(bytes).digest('hex')])),cases:[]};
try{for(const mode of ['retained','retired']){
 const context=await browser.newContext(),page=await context.newPage(),errors=[],failed=[],consoleErrors=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text());});context.on('requestfailed',r=>failed.push({url:r.url(),error:r.failure()}));
 const offset=requests.length;await page.goto(origin+'/parent',{waitUntil:'load'});
 await page.evaluate(async()=>{await MathExerciseRuntime.whenInitialUIReady();events.push({name:'parent-initial-ui',at:performance.now()});});
 await page.waitForFunction(()=>permissionRequests.length===1);
 const before=await page.evaluate(()=>({events,permissionRequests,crossOriginIsolated,sharedArrayBuffer:typeof SharedArrayBuffer==='function'}));assert.equal(before.crossOriginIsolated,true);assert.equal(before.sharedArrayBuffer,true);assert.ok(before.events.some(e=>e.name==='parent-load'));assert.ok(before.events.some(e=>e.name==='child-load'));assert.ok(before.events.some(e=>e.name==='parent-initial-ui'));assert.ok(!requests.slice(offset).some(p=>p.includes('/sre/')),'no SRE worker or locale download before COI decision');
 let glyphs=0;
 if(mode==='retained'){
  const localeResponse=page.waitForResponse(r=>r.url().endsWith('/sre/mathmaps/nemeth.json')&&r.status()===200);await page.evaluate(()=>releaseCoi());const frame=page.frames().find(f=>f.url()===origin+'/child');
  await frame.evaluate(async()=>{await MathJax.startup.promise;const node=await MathJax.tex2svgPromise('x+1');document.body.appendChild(node);});
  await frame.waitForSelector('mjx-container svg');glyphs=await frame.locator('mjx-container svg path').count();assert.ok(glyphs>0);
  await localeResponse;
 }else{await page.goto('about:blank',{waitUntil:'load'});}
 const traffic=requests.slice(offset);if(mode==='retired')assert.ok(!traffic.some(p=>p.includes('/sre/')));
 assert.deepEqual(errors,[]);assert.deepEqual(failed,[]);assert.deepEqual(consoleErrors,[]);
 const afterDecision=mode==='retained'?await page.evaluate(()=>({events})):null;const timeline=requestTimeline.slice(offset);if(mode==='retained'){const decision=afterDecision.events.find(e=>e.name==='decision');assert.ok(decision);assert.ok(timeline.filter(e=>e.path.includes('/sre/')).every(e=>e.at>=decision.epoch));}report.cases.push({mode,beforeDecision:before,afterDecision,requests:traffic,timeline,glyphs,errors,failed,consoleErrors});await context.close();
}report.assets=assets;report.passed=true;
}catch(error){report.failure=String(error);report.allRequests=requests;throw error;}finally{await browser.close();await new Promise(done=>server.close(done));await writeFile(join(root,'browser.json'),JSON.stringify(report,null,2)+'\n');}
console.log(JSON.stringify({passed:report.passed,cases:report.cases.length}));
