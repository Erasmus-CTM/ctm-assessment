import base64,hashlib,json
from pathlib import Path
from html.parser import HTMLParser
root=Path(__file__).parent;project=root/'project';record=json.loads((project/'.private-extensions/resolved-repos.json').read_text());pins=json.loads(Path('/workspace/work/assessment-sre/integration/feedback/repos.json').read_text())['repositories']
for name,spec in pins.items():
 if name!='ctm-assessment':assert record['repositories'][name]['commit']==spec['commit'],name
count=0
for folder,files in record['extension_sha256'].items():
 for name,digest in files.items():
  p=project/'_extensions'/folder/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,(folder,name);count+=1
class Tags(HTMLParser):
 def __init__(self):super().__init__();self.scripts=[];self.frames=[];self.head=False
 def handle_starttag(self,tag,attrs):
  d=dict(attrs)
  if tag=='head':self.head=True
  if tag=='script':self.scripts.append((d,self.head))
  if tag=='iframe':self.frames.append(d)
 def handle_endtag(self,tag):
  if tag=='head':self.head=False
html=(project/'closure.html').read_text();tags=Tags();tags.feed(html);coi=[(d,h) for d,h in tags.scripts if 'ctm-coi-frame-startup' in d.get('src','')];assert len(coi)==1
attrs,head=coi[0];assert head and not any(x in attrs for x in ('async','defer','type'))
coordinator=project/attrs['src'];canonical=project/'_extensions/ctm-libs/runtime/coi-frame-startup.js';assert coordinator.read_bytes()==canonical.read_bytes()
assert any('qpyodide-document-status.js' in d.get('src','') and d.get('type')=='module' for d,h in tags.scripts)
status=(project/'_extensions/pyodide-interaktiv/qpyodide-document-status.js').read_text();assert 'qpyodideCoiSettled' in status and 'whenInitialUIReady' in status
helper=(project/'_extensions/ctm-libs/runtime/mathjax-opaque-adaptor.js').read_bytes();prefix=b'globalThis.CTM_COI_FRAME_STARTUP={protocol:"ctm-coi-frame-startup",version:1};\n';assert len(tags.frames)==1
frame=tags.frames[0];child=base64.b64decode(frame['src'].split(',',1)[1]).decode();ct=Tags();ct.feed(child);preload=[d for d,h in ct.scripts if d.get('src','').startswith('data:text/javascript;base64,')];assert any(base64.b64decode(d['src'].split(',',1)[1])==prefix+helper for d in preload)
assert 'sandbox' in frame and frame['sandbox']=='allow-scripts'
for marker in ('closure-math','closure-python','closure-ide','closure-board'):assert marker in html,marker
wheel=project/'_extensions/ctm-checkers/ctm_checkers-0.6.1.dev0-py3-none-any.whl';assert hashlib.sha256(wheel.read_bytes()).hexdigest()=='2c9935c6aa60041bbcb13d751db98c613feb69fd7077ebd3d4d296f8ac376f54'
receipt={'passed':True,'scope':'Canonical default installer inventory + one actual Quarto mixed math/Python/IDE/opaque-board render. No browser/CDN/actual-reload grading claim. No review-ref overrides, approvals or native history writes.','componentRefs':{k:v.get('commit') for k,v in pins.items()},'filesHashVerified':count,'coordinatorSHA256':hashlib.sha256(coordinator.read_bytes()).hexdigest(),'helperSHA256':hashlib.sha256(helper).hexdigest(),'checkerWheelSHA256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'coordinatorClassicHead':True,'childCapabilityCanonicalBytes':True,'pyoSettlementPromisePresent':True,'htmlSHA256':hashlib.sha256(html.encode()).hexdigest()}
(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
