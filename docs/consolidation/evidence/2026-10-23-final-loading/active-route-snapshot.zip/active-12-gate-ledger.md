# Active CTM route gate ledger

Fetched 2026-10-23T20:55:18.040Z. This is a read-only audit of12active routes, not a declaration that all57historical drafts are ready. All12are open, draft, unmerged and GitHub reports mergeable=true. Git ref heads were independently read; mergeability measures conflicts, not acceptance. No readiness decision is made before final true first-visit evidence.

| Route | Head | Actual base head | Current exact-head workflows |
|---|---|---|---|
| Erasmus-CTM/ctm-assessment#52 | 2c288f6b | 1e2df499 | 5 pass, 0 running; 0 intentionally skipped |
| Erasmus-CTM/ctm-assessment#56 | 8b46f20e | 2c288f6b | 5 pass, 0 running; 0 intentionally skipped |
| Erasmus-CTM/ctm-libs#42 | 626b5466 | a6161c3e | 3 pass, 0 running; 0 intentionally skipped |
| Erasmus-CTM/ctm-libs#43 | d989919c | 626b5466 (cached PR field stale) | 3 pass, 0 running; 0 intentionally skipped |
| Erasmus-CTM/math-exercise#31 | 97a7dc5b | b282111d | 5 pass, 0 running; 0 intentionally skipped |
| Erasmus-CTM/math-exercise#32 | 74946e50 | 97a7dc5b (cached PR field stale) | 3 pass, 2 running; 0 intentionally skipped |
| Erasmus-CTM/py-exercise#13 | 18e6f1eb | 2096710d | 2 pass, 0 running; 0 intentionally skipped |
| Erasmus-CTM/pyodide-interaktiv#11 | 50795009 | a5095406 | 4 pass, 0 running; 0 intentionally skipped |
| Erasmus-CTM/ctm-checkers#25 | 5976f1a9 | 76ec14ea | 1 pass, 0 running; 0 intentionally skipped |
| aacchhee/ctm-demo#19 | 58fe28bb | d65eea62 | 1 pass, 1 running; 1 intentionally skipped |
| aacchhee/ctm-demo#20 | 3f6336a4 | 58fe28bb (cached PR field stale) | 1 pass, 2 running; 3 intentionally skipped |
| aacchhee/quarto-course-template#1 | 8cd533f1 | efa6afbd | 1 pass, 0 running; 0 intentionally skipped |

Actual refs, individual fetch timestamps, run IDs and route-specific stated requirements/limits are in [the machine ledger](active-12-gate-ledger.json). Source parent stops are preserved; this audit does not walk or green-label the whole dependency history.

## Erasmus-CTM/ctm-assessment#52

- Pin/source and rendered comparisons already have frozen evidence; retain original raw failing supplemental reports and do not call them current acceptance.
- Root/AC must map the coherent demo board coverage to the existing stated gate. Do not launch a new three-course/protected-course campaign solely to replace historical failures.

Stated scope/acceptance limits:

- Optional preloader activation is a separate later production change in56;52itself is the authorized upstream pin.
- Offline acceptance and Ingmat3a rollout are separate release/activation conditions.

## Erasmus-CTM/ctm-assessment#56

- No additional current source blocker found: all5exact-headCIchecks pass; canonical no-override minimal-default install plus mixed-page render verifies133inventoryhashes.
- Dependency pin merge order remains AC-owned; preserve current42/31/readiness defaults and separate43/32authoring overrides.

Stated scope/acceptance limits:

- Package/render closure is not browser grading or universal course acceptance.
- Prior nativeparitydb1proof remains exact historical head; current math32fullparity74946 also passed at fetch.

## Erasmus-CTM/ctm-libs#42

- No new source blocker found: all3exact-headworkflows pass; source28and real transport/SRE evidence remain bounded.
- Retain nativeHEAD/CDNAB and actualMonacoAMD proofs rather than the superseded overbroad original fixture.

Stated scope/acceptance limits:

- Functional success alone cannot clear raw errors/request lifecycle.
- Maxima independent; missingJSXGraph/speech controls required in composed proof.

## Erasmus-CTM/ctm-libs#43

- Map shared-foundation wiring to already implemented dependentmath32/checker25 and their installed/source/browser evidence; do not treat old foundation disclaimer as proof those dependent sources are still missing.
- No new shared-source blocker: all3exact-headworkflows pass.

Stated scope/acceptance limits:

- Live hosted bot activation is not performed by this foundation PR and remains a separate activation decision.
- Sourcebody contains historical39f/19bheads; current authoritative Git head/base are d989/626b.

## Erasmus-CTM/math-exercise#31

- No additional source blocker found: all5exact-headworkflows pass; unchanged product source and focusedcompat49/49 retain their scope.
- Headered historical demo evidence applies to older tuple; do not present it as new current5pageproof.

Stated scope/acceptance limits:

- Old renderer-fault UI control used a stubbed grader/store; actual grading containment must come from composed first-start controls.

## Erasmus-CTM/math-exercise#32

- At initialfetch current standalone/declarative/paritypassed; compatibility/browser stillrunning. Require terminal current-headresults.
- Windows process-tree teardown is untested; root/AC must explicitly classify this stated limitation before readiness rather than imply LinuxCI proved it.

Stated scope/acceptance limits:

- Explicit CTM_VARIANTS=review is documented behavior; automatic ordinary-preview detection was not found and is not silently claimed.
- Isolated studentviews omit ambient diagrams/coursecontext; no invented fullcourseproof.
- Required publishing still needs real approvals; synthetic fixtures do not authorize teaching variants.

## Erasmus-CTM/py-exercise#13

- No new source blocker found: both exact-headworkflows pass; deferred/failededitor sibling controls retained.
- Integration must select reviewed sharedlibrary refs explicitly because standaloneCIpin remains earlier dfe foundation; newdefault56 and parent19do so.

Stated scope/acceptance limits:

- No course/static-host rollout is authorized by component readiness.

## Erasmus-CTM/pyodide-interaktiv#11

- No new source blocker found: all4exact-headworkflows pass; canonical sync from42=626b verified, no generatedhandedits.
- Keep controlledSRE/localvendor2case proof separate from actualserviceworker/CDN/dataURL/Pyodide composed gate.

Stated scope/acceptance limits:

- Course/static go-ahead separate; ordinaryCheck/Python/Maxima isolation preserved.

## Erasmus-CTM/ctm-checkers#25

- Exact-headsource/wheelCI passed; installednative/actualstudentview/localbrowser/fakeartifactsourceproof already exists and must stay scoped.
- Livebot/Pages/mainpublisher concurrency and required-check attachment are futureactivation conditions, not a request to deploy/activate before merging inactive reviewed source. Root/AC should state that classification explicitly when removing HOLD.

Stated scope/acceptance limits:

- No live comments, botdispatch, workflowactivation or deployment authorized/performed.
- SourceCI includes documentedenvironment skips; not all testleaves are zero-skip.

## aacchhee/ctm-demo#19

- Currentcandidateworkflowsourcejob passes but artifactjob is intentionallyskipped; do not silently claim a fresh five-pagecampaign.
- Retain old5pagegrading/save/export/reset/crosstab/nav/language/print proof and its WebKitlatependingPythonrequest limitations. Root/AC must decide whether unchangedpagecode plus currentboundedreadinessproof is enough for this PR scope; no broad rerun solely for iconcolor.

Stated scope/acceptance limits:

- Currentparent gate is a boundedreadinesspage with actualopaque board, not universalcourse/input/Stop/offline acceptance.
- Legacy fourSTACKparameterrecipes unchanged; parent must remain legacy-compatible.

## aacchhee/ctm-demo#20

- Require currentauthoringartifactjob terminalsuccess;99retainedproposals/teacher/source/nohistory proof stays exact and separate from 1pageloading gate.
- Zero realapprovals is intentional for reviewonly migration; requiredpublish must refuse, not be made green by fakeapprovals.
- Body still references old5bd stackbase/oldfixedstudenttuple; update readinessdescription to actualcurrenthead3f6336/base58fe once finalresults reviewed.

Stated scope/acceptance limits:

- Fourboardcontrolledproof used explicitgrader/runtime stubs and localexactassets; never label it realPython/CDN grading.
- No new broad99generation or protectedstudentdeploy needed.

## aacchhee/quarto-course-template#1

- No new source blocker found: exactheadcanonicalnative-task install/filename-spaces/teacher-tests/readonlymanifest/helperGET CI passes.
- Those listed outside-slice capabilities should remain limitations, not silently become new mandatory mergework. Root/AC defines final acceptance; inactiveworkflows/sourceonly scope preserved.

Stated scope/acceptance limits:

- Frozen proof tuple predates finalruntime tuple; proves unchangedtask/installation contract only.
- Legacy scripts/setup.py still insufficient for nativeauthoring; documentedcanonicalauthoringpack required.

## Historical inventory remains separate

The original19:22snapshot covered59open PRs,57draft and2non-draft across13repos; separately read upstream PR2 made60open/57draft/3non-draft across14repos. That inventory includes older heads of the active subset. Twelve active readiness/authoring routes are not57additional drafts and their green source checks cannot certify the rest.

Assessment41 is a superseded conflict, not a remaining unique source implementation. The bounded actual-base1e2 merge-tree audit found exactly four conflicts whose obsolete sides remove manual campaign controls, modern renderer/context arguments or strict tests. Choosing the reviewed parent leaves the exact parent tree and no unique feature. Assessment43 was merge-clean against actual1e2 and its merge tree had zero file differences from that parent. Neither should be merged merely to improve a dashboard. No history rewrite, closure or merge is authorized by this classification.

Assessment51's corrected diagnostic contract passed three engines, including actual WebKit native/inactive positive controls and zero-error combined mode; it is a diagnostic completion, not universal course acceptance. Historical assessment28 retains a real D2/stage2 failure and old WebKit integration failures. Assessment31/32 policy experiments retain raw ResizeObserver failures on immutable older fixtures. Historical checker11/12/13, other runtime/STACK routes and protectedIngmat17 remain outside this twelve-route closure; their actual scopes need their own work, not blanket readiness. See ../draft-gate-audit/{report.md,assessment-41-43-51.md,assessment-28-31-32-triage.md} for exact historical classifications and immutable evidence.

Inactive bot/hosting templates must remain inactive under the no-deploy/no-live-message constraints. Activation checks, public Pages output, workflow-required-check attachment and main-publisher coordination are future activation conditions unless AC explicitly makes them source merge criteria. Likewise zero teacher approvals on authoring-only demo20 is intentional: required student rendering must refuse them. Do not manufacture approvals or student clearance to make authoring source ready.

The old headered five-page demo proof has exact frozen refs and limited pending-request scope. Current one-page first-visit evidence, even when green, does not silently become a new five-page or universal course/offline/input/Stop result. Root/AC must explicitly assess unchanged page behavior against the existing scoped proof, rather than rerun broad campaigns solely for icons or silently erase that limitation. AC alone merges; Ingmat3a main remains protected.

