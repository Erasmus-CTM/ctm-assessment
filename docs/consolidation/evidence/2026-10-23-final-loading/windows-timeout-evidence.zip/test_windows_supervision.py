"""Actual Windows timeout-only process-tree proof against the checked-out product."""
import ctypes
from ctypes import wintypes
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]

def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / '_extensions/math-exercise' / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

@unittest.skipUnless(os.name == 'nt', 'actual Windows process handles required')
class WindowsTimeoutTrees(unittest.TestCase):
    def run_tree(self, kind):
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        kernel.WaitForSingleObject.restype = wintypes.DWORD
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            marker = root / 'pids.json'
            worker = root / 'worker.py'
            worker.write_text('import os,sys,subprocess,time,json\nfrom pathlib import Path\n'
                "child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(120)'])\n"
                f'Path({str(marker)!r}).write_text(json.dumps([os.getpid(),child.pid]))\n'
                'time.sleep(120)\n', encoding='utf-8')
            # Capture real process handles while both processes are alive; handles
            # remain valid after exit and avoid PID reuse/process-list ambiguity.
            handles = []
            import threading
            def capture():
                limit = time.monotonic() + 15
                while time.monotonic() < limit:
                    if marker.exists():
                        attempt = []
                        try:
                            for pid in json.loads(marker.read_text()):
                                handle = kernel.OpenProcess(0x00100000, False, pid)
                                if not handle:
                                    raise OSError(ctypes.get_last_error(), 'OpenProcess failed')
                                attempt.append((pid, handle))
                            handles.extend(attempt)
                            return
                        except (json.JSONDecodeError, OSError):
                            for pid, handle in attempt:
                                kernel.CloseHandle(handle)
                    time.sleep(.02)
            observer = threading.Thread(target=capture)
            observer.start()
            started = time.monotonic()
            try:
                if kind == 'native':
                    module = load('native_supervisor', 'question-variants.py')
                    module.__file__ = str(worker)
                    code, stdout, stderr = module.supervised(b'{}', timeout=8)
                    self.assertEqual(code, 1)
                    self.assertEqual(stdout, b'')
                    self.assertIn(b'time budget exceeded', stderr)
                else:
                    module = load('render_supervisor', 'variants-review.py')
                    with self.assertRaisesRegex(ValueError, 'time budget exceeded'):
                        module.Review.render_command([sys.executable, str(worker)], root, os.environ, timeout=8)
                elapsed = time.monotonic() - started
                observer.join(timeout=2)
                self.assertEqual(len(handles), 2, 'leader and descendant must both start and be observed')
                self.assertLess(elapsed, 16, 'timeout plus bounded taskkill/cleanup exceeded')
                for pid, handle in handles:
                    self.assertEqual(kernel.WaitForSingleObject(handle, 3000), 0, f'process {pid} survived timeout teardown')
                self.assertFalse((root / '_variants').exists())
                print(json.dumps({'supervisor': kind, 'elapsed': elapsed, 'pids': [p for p,h in handles], 'stopped': True}), flush=True)
            finally:
                observer.join(timeout=16)
                if marker.exists():
                    for pid in json.loads(marker.read_text()):
                        subprocess.run(['taskkill','/F','/T','/PID',str(pid)], capture_output=True, timeout=3)
                for pid, handle in handles:
                    kernel.CloseHandle(handle)

    def test_native_request_timeout_stops_real_descendant(self):
        self.run_tree('native')

    def test_review_render_timeout_stops_real_descendant(self):
        self.run_tree('render')

if __name__ == '__main__':
    unittest.main(verbosity=2)
