# Focused variants source, module and local browser seams

This archive preserves narrow evidence before later rendered-review/workflow additions. It is not final static first-visit, full runtime, student-course or deployment acceptance. Consult each JSON report's source hashes and scope; source-only privacy followups do not retroactively change an earlier browser tuple.

The consumer and ordinary-pool browser reports use real local canonical modules and KaTeX with explicit runtime/grader stubs. Missing-helper faults are intentional and retained. The custom scalar/vector packet report uses actual JS-produced packets and the installed native checker wheel, not Pyodide bootstrap or named matrix contexts. Boards reports prove optional transport only. The connected helper browser report uses installed working-copy source, not an immutable final Git tuple; subsequent exact-source installed verification is separate. Original failed favicon fixture and raw errors are retained, never waived.

Feedback reset uses actual canonical JSDOM modules and fake provider transport. Four tests, including actual Quarto and cancellation during asynchronous collection before provider submission, passed and were independently repeated. The note records initial harness/environment corrections.

No real teaching notes were approved. No live API comment, workflow dispatch, provider request, merge, deployment or tag was used for these proofs. SHA256SUMS lists each archived file.
