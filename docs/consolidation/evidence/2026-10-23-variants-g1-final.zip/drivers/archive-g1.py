from pathlib import Path
import zipfile,hashlib,json
r=Path('/workspace/work/variants-install');items={}
def add(p,label):
 p=Path(p)
 if p.is_file():items[label]=p
 elif p.is_dir():
  for f in sorted(p.rglob('*')):
   if f.is_file() and f.name != 'archive-receipt.json':items[label+'/'+f.relative_to(p).as_posix()]=f
add(r/'evidence/g1-final','canonical')
add(r/'check-g1-provenance.py','drivers/check-g1-provenance.py')
add(Path(__file__),'drivers/archive-g1.py')
add('/workspace/work/g1-frontend-evidence','frontend')
add(r/'sources/math-exercise/tests/native-consumer.test.mjs','frontend/native-consumer.test.mjs')
add(r/'sources/math-exercise/tests/helpers','frontend/helpers')
add('/workspace/work/g1-catalog-browser','browser')
add('/workspace/ctm-checkers/work/g1-source-evidence','native-source-proof')
base=Path('/workspace/work/g1-export')
for name in ['receipt.json','response.json','result.json','run.py','negative.py','helper-tests.log']:
 add(base/name,'exporter/'+name)
add(base/'project/lesson.qmd','exporter/lesson.qmd')
add(base/'native-roundtrip/report.json','exporter/native-roundtrip-report.json')
add(base/'native-roundtrip/variants-records.json','exporter/native-roundtrip-records.json')
for language in ['default','nb']:add(base/'out'/language/'index.html','exporter/student-'+language+'.html')
add(base/'native-roundtrip/verified/review/q.html','exporter/review-q.html')
for name in ['math-exercise.js','native-variants.lua','math-exercise.lua','question-variants.py','variants-review.py']:
 add(r/'g1-project/_extensions/math-exercise'/name,'published-source/math-exercise/'+name)
add(r/'g1-project/_extensions/ctm-checkers/native-authoring/ctm_variants/preview_assets.py','published-source/native/preview_assets.py')
archive=r/'g1-final-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for label,p in sorted(items.items()):z.write(p,label)
receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'entries':len(items),'scope':'G1 final delta only; omitted2.4MBgenerated duplicated assets, retained all65 path/hash/size inventory and actual student HTML2+review HTML'}
(r/'evidence/g1-final/archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
