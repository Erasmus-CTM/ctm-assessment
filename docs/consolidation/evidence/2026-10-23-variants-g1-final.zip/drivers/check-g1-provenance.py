from pathlib import Path
import hashlib,json,subprocess
r=Path('/workspace/work/variants-install');project=r/'g1-project';ext=project/'_extensions';out=r/'evidence/g1-final'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=json.loads((project/'.private-extensions/resolved-repos.json').read_text())
expected={'math-exercise':'77e27c4c5acbfea5815980e75b92b7134298bcdb','ctm-checkers':'0581521595fc9eb775a818c2771faedb2052554e','ctm-libs':'39f9b24c94c2c7c79b18d3dcb9b21d4042834691','ctm-assessment':'9504873c236e838f644c1a2807720ad419734554'}
for n,v in record['repositories'].items():
 assert not v['dirty_files'],n
 if n in expected:assert v['commit']==expected[n],(n,v['commit'])
for folder,files in record['extension_sha256'].items():
 for name,digest in files.items():assert h(ext/folder/name)==digest,(folder,name)
print('PASS exact published clean tuple and every canonical installed extension hash')
proof='07cb2144f41361f824e81b677af17eb38d6b633a';source=r/'sources/math-exercise';compares={}
for f in (source/'_extensions/math-exercise').rglob('*'):
 if not f.is_file():continue
 rel=f.relative_to(source).as_posix()
 old=subprocess.check_output(['git','show',proof+':'+rel],cwd='/workspace/math-exercise')
 assert hashlib.sha256(old).hexdigest()==h(f),rel
 compares[rel]=h(f)
print('PASS actual exporter proof07cb extension bytes equal published77e27 (all component files)')
js={}
for language in ['default','nb']:
 for name in ['math-exercise.js','math-store.js']:
  p=Path('/workspace/work/g1-export/out')/language/'preview_files/libs/quarto-contrib/math-exercise-0.11.0'/name
  assert h(p)==h(ext/'math-exercise'/name)
  js[language+'/'+name]=h(p)
print('PASS both actual exported languages runtime JS equal canonical installed runtime')
old=json.loads((r/'project/.private-extensions/resolved-repos.json').read_text())['extension_sha256']['ctm-checkers']
new=record['extension_sha256']['ctm-checkers'];before={k:v for k,v in old.items() if k.startswith('native-authoring/')};after={k:v for k,v in new.items() if k.startswith('native-authoring/')}
assert len(before)==24 and len(after)==25
assert set(after)-set(before)=={'native-authoring/ctm_variants/preview_assets.py'}
assert not set(before)-set(after)
descriptor=json.loads((ext/'ctm-checkers/checkers.json').read_text());wheel=ext/'ctm-checkers'/descriptor['wheel'];assert h(wheel)==descriptor['sha256']=='2c9935c6aa60041bbcb13d751db98c613feb69fd7077ebd3d4d296f8ac376f54'
print('PASS native inventory24→25 only preview_assets.py added; browser wheel unchanged')
verified=Path('/workspace/work/g1-export/native-roundtrip/verified');inventory={f.relative_to(verified).as_posix():{'sha256':h(f),'bytes':f.stat().st_size} for f in sorted(verified.rglob('*')) if f.is_file()};assert len(inventory)==65
(out/'all65-generated-assets.json').write_text(json.dumps(inventory,indent=2)+'\n')
(out/'canonical-resolved-repos.json').write_text(json.dumps(record,indent=2)+'\n')
summary={'scope':'Canonical G1 published tuple/native inventory/runtime asset provenance only; reused actual source Quarto2language export, no rerender or generation campaign','tuple':expected,'exporterProofCommit':proof,'allComponentSourceSHA256':compares,'actualExportRuntimeSHA256':js,'nativeBefore':len(before),'nativeAfter':len(after),'nativeAdded':sorted(set(after)-set(before)),'nativeChanged':sorted(k for k in before if before[k]!=after[k]),'browserWheelUnchangedSHA256':h(wheel),'generatedFiles':65,'generatedBytes':sum(x['bytes'] for x in inventory.values()),'limitations':['Browser6 checks use explicit runtime/grader stub and blocked external KaTeX','Fake hosting transport only; no external API mutations, merge, deploy or tag','Not CDN, dataURL firstvisit or Pyodide bootstrap acceptance']}
(out/'summary-g1-final.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
