import importlib.util,json
from pathlib import Path
p=Path('/workspace/math-exercise/_extensions/math-exercise/question-variants.py')
s=importlib.util.spec_from_file_location('wrapper',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.install_imports()
v=m.current_source(dict(projectRoot='/workspace/work/g1-export/project',file='lesson.qmd',sourceFile='lesson.qmd',label='q'))
v.update(version=1,action='resolve-more',renderMode='review',approval='required',baseHash=None,manifest='_variants/q.yml')
r=m.supervised(json.dumps(v).encode());assert r[0]==0,r;Path("/workspace/work/g1-export/response.json").write_bytes(r[1])
