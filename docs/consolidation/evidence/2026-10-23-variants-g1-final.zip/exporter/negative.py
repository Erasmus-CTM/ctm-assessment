import importlib.util,json,tempfile,copy
from pathlib import Path
p=Path('/workspace/math-exercise/_extensions/math-exercise/variants-review.py');s=importlib.util.spec_from_file_location('rv',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=m.Review('/workspace/work/g1-export/project','lesson.qmd','q');v=json.loads(Path('/workspace/work/g1-export/response.json').read_text())
try:
 for label,mutate in [('lease',lambda x:x.update(baseHash='bad')),('decisions',lambda x:x['manifest']['events'].append({'bad':1})),('record',lambda x:x['records'][0].update(note='tampered'))]:
  x=copy.deepcopy(v);mutate(x)
  with tempfile.TemporaryDirectory() as d:
   try:r.export_students(x,Path(d)/'out','students/q')
   except (ValueError,KeyError):print(label,'PASS')
   else:raise AssertionError(label)
finally:r.preview_directory.cleanup()
